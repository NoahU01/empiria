# Postings Daniel Ströbel – LinkedIn (Entwürfe, Stand 12.10.2026)

## 01 · Di 20.10. · 01 Strategie im Alltag · Szene · B Foto mit Satz

Bild: rp01.jpg · Szene · B Foto mit Satz

Die Strategie gibt der Chef vor. Das ist sein Job.

Ich erlebe es immer wieder: Eine neue Strategie soll her, und der erste Schritt ist ein großer Workshop mit dem ganzen Team. Alle sollen mitreden, alle sollen sich wiederfinden.

In der Praxis holst du damit Menschen an den Tisch, die nie gelernt haben, über Strategie zu sprechen, und denen die Erfahrung dafür fehlt. Heraus kommt ein Kompromiss, auf den sich alle einigen können. Schlechtes Mittelmaß.

Nebenbei entsteht Unsicherheit. Wenn der Chef fragt, wo es hingehen soll, wirkt es, als wüsste der Trainer nicht, wohin die Mannschaft laufen soll.

Die Reihenfolge ist eine andere. Zuerst klärt die Führungskraft, wo der Bereich hinwill und wie er dort erfolgreich ist. Dafür braucht es keinen Zweitagesworkshop, für den Einstieg reichen zwei, drei Gespräche. Danach kommt das Team dazu, wenn es um die Umsetzung geht.

Wer oben steht und selbst kein Bild hat, wohin es geht, kann das von seinen Führungskräften auch nicht verlangen.

## 02 · Mi 21.10. · 02 Komplexe Themen · Modell · A Why · How · Next

Bild: rp02.jpg · Modell · A Why · How · Next

Viele Vorstandsvorlagen sind vollständig und trotzdem nicht entscheidbar.

Wer ein Fachthema einbringt, präsentiert meist bis ins letzte Detail. Der Vorstand weiß danach viel, nur nicht, was das Thema für das Unternehmen bedeutet. Dann geht es in die nächste Schleife.

Drei Fragen reichen, in dieser Reihenfolge:

Why. Welche Bedeutung hat dieses Thema für uns und unser Unternehmen? Kurz und auf den Punkt.

How. Wie gehen wir grundsätzlich vor? Grundsätzlich heißt: ohne die Einzelprobleme, solange die Gesamtwirkung nicht klar ist.

What next. Was ist der konkrete nächste Schritt, damit es vorangeht?

Das klingt einfach, und trotzdem lässt es sich sehr ungeschickt aufbauen. Prüf deine nächste Vorlage gegen diese drei Fragen, bevor du an den Folien feilst.

## 03 · Do 22.10. · 01 Strategie im Alltag · Szene · B Foto mit Satz (Porträt)

Bild: rp03.jpg · Szene · B Foto mit Satz (Porträt)

„Daniel, Führung macht einsam. Je höher du kommst, desto weniger sagt dir jemand die Wahrheit.“

Diesen Satz hat mir ein ehemaliger Vorstand gesagt, mit dem ich bis heute befreundet bin. Er begleitet mich in fast jedem Projekt.

Ein Vorstand braucht mindestens einen Menschen, der auf Augenhöhe offen mit ihm spricht. Jemanden, der eine andere Meinung fundiert vertritt, ohne Angst, weil er von ihr überzeugt ist. Und der den nächsten Schritt aufzeigt, weil sich ein Vorstand gar nicht um alle Themen selbst kümmern kann.

Wenn du selbst führst, schreib dir heute einen Namen auf: Wer sagt dir die Wahrheit? Fällt dir niemand ein, ist das die wichtigste Aufgabe dieser Woche.

## 04 · Mo 26.10. · 01 Strategie im Alltag · Frage · E Skala

Bild: rp04.jpg · Frage · E Skala

Wie viel deiner Woche zahlt auf die Strategie ein?

Im Alltag kommt ständig etwas hoch: ein dringender Sachverhalt, eine Vorstandsbeschwerde, ein Termin, der brennt. Das muss heute geregelt werden. Gleichzeitig steht irgendwo eine Strategie, die erreicht werden soll.

In Bereichen, in denen Strategie wirkt, ist beides sauber getrennt. Dort ist jederzeit klar, womit man sich beschäftigt und womit nicht, damit die Strategie umgesetzt wird.

Ein ehrlicher Test für diese Woche: Geh deinen Kalender durch und markiere jeden Termin, der direkt auf die Strategie einzahlt. Der Rest ist Tagesgeschäft. Das Verhältnis zeigt dir, wo du ansetzen musst.

## 05 · Di 27.10. · 02 Komplexe Themen · Szene · A Foto pur (Flipchart)

Bild: rp05.jpg · Szene · A Foto pur (Flipchart)

What's in it for me?

Diese Frage stellt sich jeder Vertriebspartner, wenn ein neues Thema auf ihn zukommt. Meist leise.

Bei Vertriebstagungen und Markteinführungen erlebe ich oft das Gegenteil von dem, was hilft: viele richtige Fakten, viele bunte Folien, und am Ende weiß der Vertrieb nicht, was er jetzt tun soll.

Auf dem Flipchart steht der Satz, mit dem wir jede Kommunikation beginnen: Was hat mein Gegenüber davon? Erst wenn das in einem Satz beantwortet ist, kommen das Warum, das Wie und der nächste Schritt.

Wenn dein Vertrieb nach der nächsten Tagung wirklich loslegen soll, schreib vorher diesen einen Satz auf. Passt er nicht in eine Zeile, ist die Botschaft noch nicht fertig.

## 06 · Mi 28.10. · 02 Komplexe Themen · Modell · E Erfolgsmap

Bild: mo5.jpg · Modell · E Erfolgsmap

Bevor du ein Thema vorantreibst, brauchst du deine Erfolgsmap.

Niemand bringt ein Thema allein durch. Drei Fragen, bevor es losgeht:

• An wem richtest du dich aus?
• Wen brauchst du, um Erfolg zu haben?
• Wen hast du bisher zu wenig beachtet?

Die dritte Frage ist die unbequemste. Dort sitzen oft die Menschen, an denen ein gutes Thema später hängen bleibt.

Steht die Map, ergibt sich daraus die Taktik: mit wem du in welcher Reihenfolge sprichst und was jeder davon hat. Das ist bei jedem Thema ein bisschen anders. Ohne diese Map bleibt es Zufall.

## 07 · Do 29.10. · 01 Strategie im Alltag · Szene · F Foto mit Verlauf und Wort

Bild: rp07.jpg · Szene · F Foto mit Verlauf und Wort

Dein Vorstand gibt kein Zielbild für deinen Bereich vor? Sei froh. Das ist deine Chance.

Du baust es selbst. So, wie dein Bereich es braucht, um erfolgreich zu sein. Genau dafür trägst du als Bereichsleiter die Verantwortung.

Wer jetzt auf den Konzern, die nächste Klausur oder Vorgaben von oben wartet, verschenkt diese Chance.

Ein gutes Zielbild erkennst du daran: Jeder in deinem Bereich versteht, wie ihr funktioniert, wie ihr erfolgreich seid und was sein Beitrag dazu ist.

Fang mit einer Frage an: Wenn dein Bereich in drei Jahren richtig gut läuft, woran merkt man das am Montagmorgen?

## 08 · Fr 30.10. · Branche eingeordnet · Eingeordnet · B Zahl auf Foto

Bild: rp08.jpg · Eingeordnet · B Zahl auf Foto

77 % sagen: Das Tagesgeschäft verdrängt die strategischen Projekte. Nur 11 % sagen, die Mitarbeitenden verstehen die Strategie.

Die Zahlen stammen aus einer branchenübergreifenden Studie von Wieselhuber. Bei Versicherern erlebe ich es nicht anders.

Was heißt das für einen Bereich? Strategie braucht im Alltag einen festen Platz, sonst gewinnt immer das, was heute brennt.

Zwei Dinge helfen. Jeder kann in einem Satz sagen, wohin der Bereich will und warum, dann lassen sich Prioritäten im Alltag selbst entscheiden. Und strategische Themen bekommen feste Termine im Kalender, genauso wie das Tagesgeschäft.
