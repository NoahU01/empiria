# Postings Daniel Ströbel – LinkedIn (Entwürfe, Stand 12.10.2026)

## 01 · Mi 14.10. · 02 Komplexe Themen · Modell · E Erfolgsmap

Bild: mo5.jpg · Modell · E Erfolgsmap

Dein Thema ist fachlich sauber durchdacht. Und trotzdem kommt es nicht voran.

Das erlebe ich ständig. Und die Reaktion ist fast immer dieselbe: noch eine Analyse, noch eine Berechnung, noch tiefer in die Details.

Damit wirst du nicht erfolgreicher. Fachlich warst du vorher schon gut.

Ein Thema bewegt sich, wenn die Menschen, die du dafür brauchst, es wollen. Und jeder davon hat seinen eigenen Blickwinkel, seine eigenen Ziele und seine eigenen Gründe, Ja oder Nein zu sagen.

Der Vorstand schaut auf etwas anderes als der Vertrieb. Der Nachbarbereich fragt sich, was das für ihn bedeutet. Und irgendwo sitzt jemand, an den keiner gedacht hat und an dem das Thema am Ende hängen bleibt.

Deshalb steht bei mir vor jedem Thema die Erfolgsmap:

• An wem richtest du dich mit deinem Bereich aus? Wessen Erwartungen entscheiden, ob du als erfolgreich wahrgenommen wirst?
• Wen brauchst du, um das Thema durchzubringen?
• Wen hast du bisher zu wenig beachtet?

Und dann für jeden auf der Map: Wie schaut er auf das Thema, was will er erreichen, was treibt ihn an?

Daraus ergibt sich deine Taktik. Mit wem sprichst du zuerst, wen holst du vorher ab, welches Argument zählt bei wem?

Das ist bei jedem Thema anders, weil die Menschen andere sind.

Logik und Fachlichkeit allein haben in einer Organisation noch kein Thema durchgebracht. Das machen die Menschen.

## 02 · Do 15.10. · 01 Strategie im Alltag · Szene · F Foto mit Verlauf und Wort

Bild: rp07.jpg · Szene · F Foto mit Verlauf und Wort

Dein Vorstand gibt kein Zielbild für deinen Bereich vor? Sei froh. Das ist deine Chance.

Damit hast du die Freiheit, deinen Bereich so aufzustellen, dass er erfolgreich sein kann. Genau dafür trägst du als Bereichsleiter die Verantwortung.

Wer jetzt auf Vorgaben von oben wartet, lässt diese Freiheit liegen.

Ein wohlklingender Satz auf einer Folie hilft dabei niemandem. Ein Zielbild beschreibt das Geschäftsmodell deines Bereichs, und zwar so klar, dass jeder deiner Mitarbeiter es erklären kann:

• Für wen arbeiten wir, und welchen Mehrwert liefern wir?
• Woran wird gemessen, ob wir erfolgreich sind?
• Wie müssen wir in Zukunft funktionieren? Die beste Frage dafür: Wie würdest du deinen Bereich heute neu gründen?
• Und was ist mein eigener Beitrag dazu?

Steht das, ergibt sich die Strategie fast von allein. Sie ist die Verbindung zwischen heute und diesem Bild.

Ob ein Bereich ein echtes Zielbild hat, merke ich meist in den ersten Minuten eines Termins. Die Leute leiten ihr Thema aus dem Gesamtbild ab: warum wir heute hier sind, wo es hingehen soll, mit welchem Ergebnis wir rausgehen.

Geht es um Optionen, argumentieren sie sauber und einigen sich nicht am Ende auf einen Kompromiss.

Und sie sind spürbar motivierter, weil alles, woran sie arbeiten, einen Sinn hat.

## 03 · Fr 16.10. · 02 Komplexe Themen · Szene · A Foto pur (Flipchart)

Bild: rp05.jpg · Szene · A Foto pur (Flipchart)

What's in it for me?

Diese Frage stellt sich jeder Vertriebspartner, wenn ein neues Thema auf ihn zukommt. Er stellt sie nicht laut. Aber er entscheidet danach, ob er etwas tut.

Bei Vertriebstagungen und Markteinführungen erlebe ich es immer wieder: tolle Stimmung, viele richtige Fakten, viele bunte Folien.

Wenn ich nachfrage, wie gut die Umsetzung vorbereitet ist, kommt meist kurz ein Schlucken. Und nach vier Wochen spricht keiner mehr von der Tagung.

Deshalb steht diese Frage bei uns am Anfang jeder Vorbereitung. Sie ist das Why, und zwar aus Sicht des Zuhörers: Was bedeutet das für mich? Was bringt mir das?

Erst wenn das klar ist, kommen das How, also wie er grundsätzlich vorgeht, und das What next, der konkrete nächste Schritt.

Die zweite Frage folgt direkt: Wie zeigen wir das so, dass es sofort verstanden wird, ohne große Erklärung? Show, don't tell.

Bevor du die nächste Tagung vorbereitest: Schreib für jede Zielgruppe in einem Satz auf, was sie davon hat.

Wenn dir das schwerfällt, weiß es der Vertrieb hinterher auch nicht.

## 04 · Sa 17.10. · 03 Geschäftsmodell · Weitergedacht

Bild: rp09.jpg · Weitergedacht · Gelbe Satzkarte mit Kreis

Die meisten sehen nur die Grenzen, die heute gesteckt sind.

Das ist kein Vorwurf. Wer einen Bereich führt, denkt in dem Rahmen, den er kennt: Zuständigkeiten, Systeme, Budgets.

Und kaum jemand schlägt eine Lösung vor, die seine eigene Rolle überflüssig machen würde.

Genau deshalb lohnt es sich, die Grenzen ab und zu bewusst wegzudenken.

Mit einem Schadenchef über die Frage, wie sein Schadenmanagement aussähe, wenn er es heute ohne die gewachsenen Abläufe aufbauen würde.

Mit einem Vertriebsdirektor darüber, wie er seinen Vertrieb aufstellen würde, wenn er morgen bei null anfangen dürfte.

Die Antworten sind selten sofort umsetzbar. Aber sie zeigen, welche Grenzen wirklich gesetzt sind und welche nur Gewohnheit.

Eine Voraussetzung gibt es: Der Kern muss laufen. Wer im Alltag noch Löcher stopft, hat für solche Fragen keinen Kopf.

Welche Grenze in deinem Bereich ist eigentlich nur Gewohnheit?

## 05 · So 18.10. · Geschichten aus der Praxis · Satz

Bild: rp10.jpg · Satz · B Anführungszeichen

„Das habe ich noch nicht richtig verstanden. Können Sie mir das mal in Ihren eigenen Worten erklären?“

Diesen Satz habe ich von meinem Vorstand unzählige Male gehört. Meist in Meetings, in denen wichtige Folien gezeigt und wichtige Worte benutzt wurden.

Das Bemerkenswerte: Er hatte es fast immer längst verstanden.

Er wollte wissen, ob derjenige es verstanden hat, der das Thema präsentiert und nachher umsetzen soll.

Denn das Thema muss auch dann richtig weiterlaufen, wenn der Vorstand nicht mehr im Raum ist.

Seine kleine Mikromethode. Ganz ruhig, ohne jede Schärfe. Und jedes Mal hat sie gezeigt, ob ein Thema trägt.

Ich bewundere sie bis heute.

Für beide Seiten des Tisches steckt etwas drin:

• Wer führt, hat eine Frage, die mehr prüft als jeder Statusbericht.
• Wer präsentiert, weiß, worauf es ankommt: das Thema in eigenen Worten erklären können, ohne Folie.

## 06 · Mo 19.10. · Branche eingeordnet · Eingeordnet · B Zahl auf Foto

Bild: rp08.jpg · Eingeordnet · B Zahl auf Foto

77 % sagen: Das Tagesgeschäft verdrängt die strategischen Projekte. Nur 11 % sagen, die Mitarbeitenden verstehen die Strategie.

Die Zahlen stammen aus einer branchenübergreifenden Studie von Wieselhuber. Bei Versicherern erlebe ich es nicht anders.

Was heißt das für einen Bereich? Strategie braucht im Alltag einen festen Platz, sonst gewinnt immer das, was heute brennt.

Zwei Dinge helfen.

Jeder kann in einem Satz sagen, wohin der Bereich will und warum, dann lassen sich Prioritäten im Alltag selbst entscheiden.

Und strategische Themen bekommen feste Termine im Kalender, genauso wie das Tagesgeschäft.

## 07 · Di 20.10. · 01 Strategie im Alltag · Szene · B Foto mit Satz

Bild: rp01.jpg · Szene · B Foto mit Satz

Ich erlebe es immer wieder: Eine neue Strategie soll her, und der erste Schritt ist ein großer Workshop mit dem ganzen Team. Alle sollen mitreden, alle sollen sich wiederfinden.

In der Praxis holst du damit Menschen an den Tisch, die nie gelernt haben, über Strategie zu sprechen, und denen die Erfahrung dafür fehlt.

Heraus kommt ein Kompromiss, auf den sich alle einigen können. Schlechtes Mittelmaß.

Nebenbei entsteht Unsicherheit. Wenn der Chef fragt, wo es hingehen soll, wirkt es, als wüsste der Trainer nicht, wohin die Mannschaft laufen soll.

Die Reihenfolge ist eine andere. Zuerst klärt die Führungskraft, wo der Bereich hinwill und wie er dort erfolgreich ist.

Der Einstieg beginnt dabei nicht mit einem Zweitagesworkshop. Zwei, drei Gespräche mit mir reichen, um den Gesamtzusammenhang klar und stringent zu skizzieren.

Diesen arbeiten wir danach gezielt aus, immer nur in dem zeitlichen Umfang, den es braucht. Zwischen den Terminen arbeite ich weiter und liefere das nächste Level der Ausarbeitung.

Wer oben steht und selbst kein Bild hat, wohin es geht, kann das von seinen Führungskräften auch nicht verlangen.

## 08 · Mi 21.10. · 02 Komplexe Themen · Modell · A Why · How · Next

Bild: rp02.jpg · Modell · A Why · How · Next

„Danke. Bitte bereiten Sie das noch einmal auf.“

Drei Wochen Arbeit. Zwanzig Minuten Vorstand. Ein Satz.

Und du gehst raus und fragst dich, was du falsch gemacht hast.

Ich sage es dir ehrlich: Am Thema lag es nicht. Du hast zu viel gewusst. Und alles erzählt.

Wer sein Thema richtig gut kennt, kann am schlechtesten weglassen. Jedes Detail fühlt sich wichtig an. Ist es auch. Nur nicht für diese eine Entscheidung.

Der Vorstand denkt in dem Moment nicht: schwaches Thema. Er denkt: Was soll ich damit jetzt machen?

Er will drei Dinge wissen. Mehr nicht.

Why?
Was bedeutet das Thema für unser Unternehmen?

How?
Wie gehen wir grundsätzlich vor, um das Ergebnis zu erreichen? Die Details will er erst sehen, wenn er Ja gesagt hat.

What next?
Was muss heute entschieden werden, damit es weitergeht?

Drei Fragen, drei Sätze. Bekommst du die nicht hin, retten dich auch keine vierzig Folien.

## 09 · Do 22.10. · 01 Strategie im Alltag · Szene · B Foto mit Satz (Porträt)

Bild: rp03.jpg · Szene · B Foto mit Satz (Porträt)

Du stellst in der Runde eine Idee vor. Alle nicken. Du fragst: „Sieht das jemand anders?“ Stille.

Je höher du kommst, desto seltener sagt dir jemand ins Gesicht, was er denkt.

Mit Budget und Karriere hat das nur am Rande zu tun. Ab einer gewissen Stufe ist da Ehrfurcht.

Viele glauben, einem Vorstand oder einem Hauptabteilungsleiter dürfe man gar nicht die Wahrheit sagen. Und sie sind schlicht unsicher.

Was dir dann fehlt, ist ein Mensch auf Augenhöhe. Jemand, der
• eine andere Perspektive einnimmt und sie gut begründen kann.
• gezielte Fragen stellt, die dich wirklich zum Nachdenken bringen und dir einen anderen Blick auf die Dinge geben.
• Gesamtzusammenhänge aufzeigt und den nächsten Schritt klar benennt.

Schreibe dir heute einen Namen auf:
Wer sagt dir die Wahrheit? Ungeschönt, ohne Rücksicht auf deine Position.

Fällt dir niemand ein, ist das die wichtigste Aufgabe dieser Woche.

## 10 · Fr 23.10. · 01 Strategie im Alltag · Frage · E Skala

Bild: rp04.jpg · Frage · E Skala

Im Alltag kommt ständig etwas hoch: ein dringender Sachverhalt, eine Vorstandsbeschwerde, ein Termin, der brennt. Das muss heute geregelt werden.

Gleichzeitig steht irgendwo eine Strategie, die erreicht werden soll.

In Bereichen, in denen Strategie wirkt, ist beides sauber getrennt. Dort ist jederzeit klar, womit man sich beschäftigt und womit nicht, damit die Strategie umgesetzt wird.

Ein ehrlicher Test für diese Woche: Gehe deinen Kalender durch und markiere jeden Termin, der direkt auf die Strategie einzahlt. Der Rest ist Tagesgeschäft.

Das Verhältnis zeigt dir, wo du ansetzen musst.

Und wenn dir beim Markieren nicht klar ist, was auf deine Strategie einzahlt, dann ist die Strategie nicht klar genug.

## 11 · Sa 24.10. · 03 Geschäftsmodell · Weitergedacht

Bild: rp11.jpg · Weitergedacht · Gelbe Satzkarte

Diesen Satz habe ich letzte Woche gefühlt zehnmal gehört – von der Anwaltshotline meiner Rechtsschutzversicherung.

Ich hatte ein konkretes Thema und wollte eine Grundeinordnung. Keine abschließende Bewertung, dafür muss man in die Verträge schauen, das ist mir klar. Genau das habe ich gleich zu Beginn gesagt.

Ich wollte eine Denkhilfe für das Gespräch mit meinem Vertragspartner. Eine Richtung.

Bekommen habe ich: Verträge prüfen. Erst mit dem Vertragspartner reden. Wenn das nicht weiterhilft, anwaltlich prüfen lassen.

Keine Einordnung. Keine Richtung. Das Gespräch hätte ich mir sparen können.

Was mich daran ärgert, ist die vergebene Chance. Versicherer können ihre Leistung meistens nur im Schadenfall zeigen. Ein Rechtsschutzversicherer hat mit so einer Hotline etwas, das sich andere wünschen: mehr Kontakte mit dem Kunden, bei denen er ein echtes Problem löst.

Beim Abschluss wird genau dieser Service groß angepriesen. Und in dem Moment, in dem ich ihn brauche, bekomme ich nicht einmal eine Richtung.

Ein Feature, das im entscheidenden Moment nicht hält, was es verspricht, schadet mehr, als wenn es gar nicht da wäre.

Wer Services verantwortet, die beim Abschluss verkauft werden: Wann hat zuletzt jemand geprüft, was davon im Ernstfall beim Kunden ankommt?

## 12 · So 25.10. · 01 Strategie im Alltag · Aufgegriffen · Foto mit Satz

Bild: rp12.jpg · Aufgegriffen · Foto mit Satz

„Gute Beratung führt nicht möglichst schnell zu einer Lösung. Gute Beratung führt Schritt für Schritt zu einer begründeten Entscheidung.“

Das hat Matthias Weber, Vertriebsvorstand bei HDI Bancassurance, in seiner Montagskolumne geschrieben. Den Satz unterschreibe ich sofort.

Sein Punkt: Die Regulierung setzt den Rahmen. Den Unterschied macht, wie wir ihn mit Leben füllen.

Wie es aussieht, wenn das keiner tut, habe ich gestern erzählt. Anwaltshotline, konkrete Frage, und als Antwort immer wieder „Das kommt darauf an“. Formal alles richtig. Weitergekommen bin ich keinen Schritt.

Und genau das erlebe ich in den Häusern auch nach innen. Die Regel wird zur Begründung, warum etwas nicht geht. Keiner traut sich, eine Richtung zu geben, weil er Angst hat, sich festzulegen.

Wenn du Vertrieb oder Service führst, kannst du deinen Leuten genau hier richtig viel abnehmen.

Sie müssen wissen, wo die Grenze verläuft. Und was sie bis dahin klar sagen dürfen, ohne sich dreimal abzusichern.

Wer das weiß, gibt dem Kunden eine Richtung. Und genau dafür ruft er an.

## 13 · Mo 26.10. · 03 Geschäftsmodell · Frage · C Fragezeichen

Bild: rp13.jpg · Frage · C Fragezeichen

Diese Frage stelle ich ziemlich früh, wenn es um die Zukunft eines Bereichs geht. Und die Antwort sieht jedes Mal anders aus als das, was heute da ist.

Zuständigkeiten, Abläufe, Schnittstellen: Vieles ist einfach so gewachsen. Also baut man weiter auf dem, was da ist. Wer neu gründet, darf all das infrage stellen.

Erst wenn das Bild steht, reden wir über Strategie. Ohne dieses Bild gibt es keine gescheite Strategie. Mit ihm ergibt sie sich fast von allein. Sie ist dann der Weg von heute dorthin.

Damit aus der Frage keine Wunschliste wird, gehe ich drei Dinge durch:

• Welches Problem hat dein Kunde wirklich?
• Wie löst du es?
• Und ist er überhaupt bereit, es zu lösen?

Einen Rat gebe ich dabei jedes Mal mit: Beantworte die Frage zuerst allein.

Stellst du sie gleich deinem ganzen Team, fragt sich jeder zuerst, ob es seinen Job danach noch gibt. Und mit dieser Sorge im Kopf denkt keiner frei.

## 14 · Di 27.10. · 01 Strategie im Alltag · Szene · A Foto mit Satz

Bild: rp14.jpg · Szene · A Foto mit Satz

Als ich selbst eine Abteilung geführt habe, rund 40 Leute an zwei Standorten, habe ich eine Sache gründlich unterschätzt.

Ich dachte: Wenn die Logik stimmt, läuft der Rest. Saubere Prozesse, klare Regelungen, ordentliche Absprachen.

Das hat nicht gereicht. Nicht annähernd.

Menschen sind im Alltag viel ausgeprägter, als es jedes Persönlichkeitsmodell beschreibt. Und unter Führungskräften laufen Strömungen, die in keinem Organigramm stehen: wer welche Interessen verteidigt und wer worauf Einfluss hat.

An vielen Stellen hast du mit reiner Logik fast keine Chance.

Was wirkt, ist Führung im Alltag. Kein Mikromanagement. Aber so aufgestellt sein, dass deine Leute merken: Da ist jemand, der Richtung gibt, nachhält und entscheidet.

Bevor du die nächste Regel aufschreibst, stelle dir zwei Fragen:

• Wer muss sich dafür im Alltag anders verhalten?
• Und woran merkt er, dass es dir ernst ist?

## 15 · Mi 28.10. · 02 Führung · Modell · D Drei Kreise

Bild: rp15.jpg · Modell · D Drei Kreise

Gestern noch der stärkste Sachbearbeiter im Team. Heute Gruppenleiter. Glückwunsch, Blumen, Mail an alle.

Und dann? Nichts.

Man gibt ihm zwölf bis vierundzwanzig Monate, um hineinzuwachsen. In der Zeit läuft er im Alarmmodus: geerbte Regeltermine, unbesetzte Stellen, Löcher stopfen.

Nach einem Jahr heißt es: „Von dem hätten wir uns mehr erwartet.“

Das finde ich ganz schlimm. Am Können liegt es fast nie. Ihm fehlt das System, mit dem er das Spiel überhaupt gewinnen kann.

Bevor du das nächste Mal jemanden beförderst, kläre vorher mit ihm drei Dinge:

1. Was erwartet das Haus von dieser Rolle? In klaren Worten.
2. Wie nimmt er sein Team mit?
3. Wie trägt sein Bereich zum Erfolg des Unternehmens bei?

Eine Stunde vor dem ersten Tag. Nicht ein Jahr danach.

## 16 · Do 29.10. · Geschichten aus der Praxis · Du als Person · Foto

Bild: rp16.jpg · Du als Person · Foto

Im Sommer 2025 stand ich wieder vor dem Lloyd's Building. 25 Jahre nach meiner Zeit in der Londoner Rückversicherung.

Ich kam damals von einem ganz normalen Versicherer aus Stuttgart. Schulungen weit weg, Budget knapp.

In London war das anders. Alle Häuser saßen im selben Viertel.

Kam ein neues Thema hoch, nahm es sich eine Firma, bereitete es auf und lud ein. Kurzer Impuls nach Feierabend, danach Essen und Trinken.

Man konnte sich praktisch jeden Tag weiterbilden. Über die Grenzen der eigenen Firma hinaus.

Das habe ich mitgenommen. Zurück in Deutschland wurde daraus „90 Minuten Wissen to go“. Das Format läuft bei meinem früheren Arbeitgeber bis heute.

Das Rezept ist simpel:

1. Ein aktuelles Thema.
2. Jemand, der es kurz auf den Punkt bringt.
3. Danach Zeit zum Reden.

Mehr braucht es nicht, damit Wissen im Haus wandert.

## 17 · Fr 30.10. · Werkstatt · Werkstatt · Foto

Bild: rp17.jpg · Werkstatt · Foto

Im letzten Jahr habe ich mir KI komplett selbst beigebracht. Agenten, Automatisierungen, wie die Systeme zusammenarbeiten.

Da bleiben Nerven auf der Strecke. Manchmal fragst du dich, was das alles soll.

Gestolpert bin ich fast immer an derselben Stelle: wenn ich zu viel vorgegeben und zu wenig gefragt habe.

Was mir seitdem auffällt: Über KI diskutieren viele, die sie selbst noch nie im Kleinen eingesetzt haben. Viel Meinung, wenig Erfahrung.

Wenn du in deinem Haus über KI mitentscheidest, mache vorher diesen Test:

1. Nimm ein echtes Thema aus deiner Woche.
2. Bitte die KI, es für dich zu strukturieren.
3. Frage dreimal nach: Warum? Was fehlt? Was wäre die Gegenposition?

Eine Stunde. Danach redest du anders über KI.

## 18 · Sa 31.10. · 03 Geschäftsmodell · Weitergedacht · Foto

Bild: rp18.jpg · Weitergedacht · Foto

2017 hatten wir ein Problem. Gute Werkstudenten gingen zu den großen Autobauern, Beratungen und Banken in Stuttgart. Zu uns kleinem Haus kam kaum jemand.

Eine Ausschreibung allein bringt dich da nicht weiter.

Also die Frage: Wenn sie nicht zu uns kommen, wie kommen wir zu ihnen?

Über einen Bekannten kam der Kontakt zur Macromedia. Angeboten hatte ich einen Gastvortrag. Am Ende hatte ich die ganze Vorlesung.

Montags um 8 Uhr, auf Englisch. Für einen Nachtmenschen wie mich eine echte Prüfung.

Das Fach habe ich bewusst gewählt: Projektmanagement. Da konnte ich die Leute, die sich hervortun, später auch brauchen.

Zwei haben mich direkt gechallenged. Kurz darauf waren sie unsere Werkstudenten. Mit einem bin ich bis heute befreundet.

Wo hast du gerade einen strukturellen Nachteil? Und wohin müsstest du gehen, um ihn umzudrehen?

## 19 · So 01.11. · 03 Geschäftsmodell · Aufgegriffen · Zitatkarte

Bild: rp19.jpg · Aufgegriffen · Zitatkarte

Vor der DKM hat Tobias Knörrer, Geschäftsführer der bbg, im Interview mit VWheute etwas gesagt, das ich sofort unterschreibe. Die Frage steht im Bild.

Bei KI fragt die Branche meistens: Wie setzt der Makler KI ein? Er dreht das um: Welche Leistungen brauchen Kunden in zehn Jahren überhaupt noch?

Seine Antwort für Makler: das Urteil bei unvollständiger Information, die Fähigkeit, einen Kunden zu einer Entscheidung zu bewegen, und die Haftung für das Ergebnis.

Die Frage gehört in jeden Versicherer. In jeden einzelnen Bereich.

So gehst du sie an:

1. Schreibe auf, welche Leistungen ihr heute erbringt.
2. Markiere, was euer Kunde in zehn Jahren noch braucht.
3. Sieh dir den Rest ehrlich an.

Was übrig bleibt, gibt es oft nur, weil es schon immer da war.

## 20 · Mo 02.11. · 01 Strategie im Alltag · Szene · Postfach-Nachbau

Bild: rp27.jpg · Szene · Postfach-Nachbau

Du schreibst die dritte Mail. Du hast die Unterlagen nachgeschärft. Und das andere Team zieht trotzdem nicht mit.

Ich kenne das. Es nervt.

Der naheliegende Schluss: Die wollen nicht. Also braucht es eine Maßnahme mit dem Team.

Wenn ich in solchen Fällen genauer hinschaue, ist es fast immer etwas anderes.

Die Rollen sind nicht geklärt. Das Zielbild fehlt. Oder die anderen haben schlicht keinen Auftrag mitzumachen.

Der letzte Punkt tut am meisten weh: Nur weil du etwas willst, muss der andere Bereich nicht mitmachen. Er wird nach seinen eigenen Zielen gesteuert.

Bevor du die vierte Mail schreibst:

1. Finde heraus, woran das andere Team gemessen wird.
2. Prüfe, ob dein Thema darauf einzahlt.
3. Wenn nicht: Kläre es eine Ebene höher.

## 21 · Di 03.11. · 02 Komplexe Themen · Szene · B Foto mit Satz

Bild: rp21.jpg · Szene · B Foto mit Satz

„Warum nimmt die Bank unser Vertriebskonzept nicht an?“

Diese Frage höre ich regelmäßig. Und gleich danach die Ideen: noch ein Impuls, bessere Unterlagen, eine Schulungsrunde. Notfalls Druck.

Setze dich gedanklich einmal auf die andere Seite des Tisches.

Für die Bank sieht es oft so aus:

• zu wenig Ertrag
• zu wenige Leute, die das Thema verstanden haben
• eine Systemanbindung, die jeden Abschluss zum Ärgernis macht

Dann kannst du die Unterlagen noch so schön machen.

Ich verstehe den Wunsch, dass es dann läuft. Funktionieren wird es trotzdem nicht.

Bevor die nächste Unterlage entsteht, beantworte drei Fragen aus Sicht der Bank:

1. Was verdient sie daran?
2. Wer bei ihr versteht das Produkt wirklich?
3. Wie aufwendig ist ein Abschluss im Alltag?

Wo die Antwort schlecht ist, liegt dein Hebel.

## 22 · Mi 04.11. · 01 Strategie im Alltag · Werkzeug · Dokument-Karussell (5 Seiten)

Bild: ka1.jpg · Werkzeug · Dokument-Karussell (5 Seiten)

Wenn ich mit einer Führungskraft über Strategie rede, denkt sie meistens sofort an zwei Tage Workshop und Kärtchen an der Wand.

Ich brauche keine zwei Tage. Ich brauche zwei, drei Gespräche à eine Stunde. Am Telefon reicht.

Du bereitest nichts vor. Keine Folien. Du erzählst, was dir durch den Kopf geht. Ich frage, unterbreche, frage weiter.

Dann lege ich dir hin, was ich gehört habe. Strukturiert, neben der Logik des Geschäftsmodells Versicherung.

Das ist der Moment, auf den ich hinarbeite: Plötzlich steht da ein Bild, das du die ganze Zeit im Kopf hattest.

Danach klären wir, wen es braucht und wie die Betroffenen ticken. Erst dann geht es los.

Den ersten Schritt kannst du heute selbst machen:

Erzähle jemandem, dem du vertraust, eine Stunde lang ohne Unterlagen, wo dein Bereich hin soll. Und bitte ihn, dir zu spiegeln, was er verstanden hat.

## 23 · Do 05.11. · Geschichten aus der Praxis · Geschichte · Foto

Bild: rp23.jpg · Geschichte · Foto

Den Satz, den heute auch Vorstände über meine Arbeit sagen, hat mir zuerst eine Mitarbeiterin gespiegelt.

Wir gingen im Besprechungsraum Termine durch. Sie sagte, als wäre es das Normalste der Welt: „Im Kern laufen die Termine doch immer gleich.“

Ich: „Wie meinst du das?“

„Es kommt immer der Punkt, an dem du sagst: Eigentlich ist es doch so.

Dann stehst du auf und zeichnest die Struktur ans Flipchart. Ab da haben alle verstanden, worum es geht.“

Damals Flipchart, heute iPad. Der Moment ist geblieben.

Was ich vorher mache, kannst du auch:

1. Frage so lange, bis du die Abhängigkeiten siehst.
2. Ordne, was Überbegriff ist und was Detail. Wie im Kinderrätsel: Apfel, Birne, Kirsche, Obst.
3. Zeichne das Ganze auf ein einziges Blatt.

Wenn du „Eigentlich ist es doch so“ sagen kannst, ist die Diskussion meistens vorbei.

## 24 · Fr 06.11. · 01 Strategie im Alltag · Zum Mitnehmen · Gedankenexperiment

Bild: rp24.jpg · Zum Mitnehmen · Gedankenexperiment

Ein Gedankenexperiment für deinen Freitag.

Deine Abteilung wird morgen ausgegründet. Eigene GmbH. Sie verkauft ihre Leistung an deinen bisherigen Arbeitgeber.

Was steht auf eurer Homepage?

• Wofür seid ihr da?
• Welches Problem löst ihr für wen?
• Warum sollte das Haus euch beauftragen und es nicht selbst machen?

Jetzt die eigentliche Probe: Würde jeder in deinem Team dasselbe hineinschreiben?

Wenn ja, habt ihr ein Zielbild. Wenn nicht, weißt du, woran du die nächsten Wochen arbeitest.

So geht die Übung: Schreibe deine Fassung allein. Bitte drei Leute aus dem Team, dasselbe zu tun, ohne deine zu kennen. Dann legt ihr alles nebeneinander.

Spätestens dann wird es interessant.

## 25 · Sa 07.11. · 03 Geschäftsmodell · Weitergedacht · Foto

Bild: rp25.jpg · Weitergedacht · Foto

„Das war schon immer so.“
„Das ist bei uns gesetzt.“
„Das macht man in unserer Branche nicht.“

Drei Sätze, die ich höre, sobald es um das Geschäftsmodell von morgen geht.

Jeder ist verständlich. Und jeder nimmt eine Möglichkeit vom Tisch, bevor jemand darüber nachgedacht hat.

Ein kleiner Test fürs Wochenende:

1. Nimm eine Sache aus deinem Bereich, die als gesetzt gilt.
2. Stelle dir vor, es gäbe sie ab morgen nicht mehr.
3. Frage dich: Wer würde es merken? Was würde wirklich fehlen?

Bei manchen Dingen ist die ehrliche Antwort: niemand. Nichts.

Genau dort fängt Neudenken an.

## 26 · So 08.11. · 01 Strategie im Alltag · Aufgegriffen · Zitatkarte

Bild: rp26.jpg · Aufgegriffen · Zitatkarte

Peter Stockhorst, Digitalvorstand der Zurich Gruppe Deutschland, hat im Frühjahr gesagt, woran es bei der Umsetzung hakt. Sein Satz steht im Bild.

Ich unterschreibe ihn. Nur klingt „Mut, Führung, Tempo“ leider wie eine Folie aus dem Strategieworkshop.

Woran es im Alltag konkret scheitert, sehe ich an drei Stellen:

• Es gibt kein klares Bild, wo es hingehen soll. Dann ist jede Initiative gleich wichtig.
• Keiner entscheidet, was wegfällt. Also läuft alles parallel.
• Zwischen den Terminen passiert nichts. Das Thema wartet auf den nächsten Jour fixe.

In den Vorstandsklausuren, die ich vorbereitet habe, kam Bewegung immer dann, wenn einer in den Lead ging. Bedeutung klar, Richtung gesagt, los.

Deine Aufgabe für Montag: Schreibe deine laufenden Initiativen auf. Streiche drei. Und sage laut, wer die übrigen treibt.
