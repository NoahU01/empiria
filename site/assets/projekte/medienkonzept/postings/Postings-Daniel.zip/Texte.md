# Postings Daniel Ströbel – LinkedIn (Entwürfe, Stand 12.10.2026)

## 01 · Mi 14.10. · 02 Komplexe Themen · Modell · E Erfolgsmap

Bild: mo5.jpg · Modell · E Erfolgsmap

Dein Thema ist fachlich sauber durchdacht. Und trotzdem kommt es nicht voran.

Das erlebe ich ständig. Und die Reaktion ist fast immer dieselbe: noch eine Analyse, noch eine Berechnung, noch tiefer in die Details.

Damit wirst du nicht erfolgreicher. Fachlich warst du vorher schon gut.

Ein Thema bewegt sich, wenn die Menschen, die du dafür brauchst, es wollen. Und jeder davon hat seinen eigenen Blickwinkel, seine eigenen Ziele und seine eigenen Gründe, Ja oder Nein zu sagen.

Der Vorstand schaut auf etwas anderes als der Vertrieb. Der Nachbarbereich fragt sich, was das für ihn bedeutet. Und irgendwo sitzt jemand, an den keiner gedacht hat und an dem das Thema am Ende hängen bleibt.

Deshalb steht bei mir vor jedem Thema die Erfolgsmap:

• An wem richtest du dich mit deinem Bereich aus? Wessen Erwartungen entscheiden, ob du als erfolgreich wahrgenommen wirst?
• Wen brauchst du, um das Thema durchzubringen?
• Wen hast du bisher zu wenig beachtet?

Und dann für jeden auf der Map: Wie schaut er auf das Thema, was will er erreichen, was treibt ihn an?

Daraus ergibt sich deine Taktik. Mit wem sprichst du zuerst, wen holst du vorher ab, welches Argument zählt bei wem?

Das ist bei jedem Thema anders, weil die Menschen andere sind.

Logik und Fachlichkeit allein haben in einer Organisation noch kein Thema durchgebracht. Das machen die Menschen.

## 02 · Do 15.10. · 01 Strategie im Alltag · Szene · F Foto mit Verlauf und Wort

Bild: rp07.jpg · Szene · F Foto mit Verlauf und Wort

Dein Vorstand gibt kein Zielbild für deinen Bereich vor? Sei froh. Das ist deine Chance.

Damit hast du die Freiheit, deinen Bereich so aufzustellen, dass er erfolgreich sein kann. Genau dafür trägst du als Bereichsleiter die Verantwortung.

Wer jetzt auf Vorgaben von oben wartet, lässt diese Freiheit liegen.

Ein wohlklingender Satz auf einer Folie hilft dabei niemandem. Ein Zielbild beschreibt das Geschäftsmodell deines Bereichs, und zwar so klar, dass jeder deiner Mitarbeiter es erklären kann:

• Für wen arbeiten wir, und welchen Mehrwert liefern wir?
• Woran wird gemessen, ob wir erfolgreich sind?
• Wie müssen wir in Zukunft funktionieren? Die beste Frage dafür: Wie würdest du deinen Bereich heute neu gründen?
• Und was ist mein eigener Beitrag dazu?

Steht das, ergibt sich die Strategie fast von allein. Sie ist die Verbindung zwischen heute und diesem Bild.

Ob ein Bereich ein echtes Zielbild hat, merke ich meist in den ersten Minuten eines Termins. Die Leute leiten ihr Thema aus dem Gesamtbild ab: warum wir heute hier sind, wo es hingehen soll, mit welchem Ergebnis wir rausgehen.

Geht es um Optionen, argumentieren sie sauber und einigen sich nicht am Ende auf einen Kompromiss.

Und sie sind spürbar motivierter, weil alles, woran sie arbeiten, einen Sinn hat.

## 03 · Fr 16.10. · 02 Komplexe Themen · Szene · A Foto pur (Flipchart)

Bild: rp05.jpg · Szene · A Foto pur (Flipchart)

What's in it for me?

Diese Frage stellt sich jeder Vertriebspartner, wenn ein neues Thema auf ihn zukommt. Er stellt sie nicht laut. Aber er entscheidet danach, ob er etwas tut.

Bei Vertriebstagungen und Markteinführungen erlebe ich es immer wieder: tolle Stimmung, viele richtige Fakten, viele bunte Folien.

Wenn ich nachfrage, wie gut die Umsetzung vorbereitet ist, kommt meist kurz ein Schlucken. Und nach vier Wochen spricht keiner mehr von der Tagung.

Deshalb steht diese Frage bei uns am Anfang jeder Vorbereitung. Sie ist das Why, und zwar aus Sicht des Zuhörers: Was bedeutet das für mich? Was bringt mir das?

Erst wenn das klar ist, kommen das How, also wie er grundsätzlich vorgeht, und das What next, der konkrete nächste Schritt.

Die zweite Frage folgt direkt: Wie zeigen wir das so, dass es sofort verstanden wird, ohne große Erklärung? Show, don't tell.

Bevor du die nächste Tagung vorbereitest: Schreib für jede Zielgruppe in einem Satz auf, was sie davon hat.

Wenn dir das schwerfällt, weiß es der Vertrieb hinterher auch nicht.

## 04 · Sa 17.10. · 03 Geschäftsmodell · Weitergedacht

Bild: rp09.jpg · Weitergedacht · Gelbe Satzkarte mit Kreis

Die meisten sehen nur die Grenzen, die heute gesteckt sind.

Das ist kein Vorwurf. Wer einen Bereich führt, denkt in dem Rahmen, den er kennt: Zuständigkeiten, Systeme, Budgets.

Und kaum jemand schlägt eine Lösung vor, die seine eigene Rolle überflüssig machen würde.

Genau deshalb lohnt es sich, die Grenzen ab und zu bewusst wegzudenken.

Mit einem Schadenchef über die Frage, wie sein Schadenmanagement aussähe, wenn er es heute ohne die gewachsenen Abläufe aufbauen würde.

Mit einem Vertriebsdirektor darüber, wie er seinen Vertrieb aufstellen würde, wenn er morgen bei null anfangen dürfte.

Die Antworten sind selten sofort umsetzbar. Aber sie zeigen, welche Grenzen wirklich gesetzt sind und welche nur Gewohnheit.

Eine Voraussetzung gibt es: Der Kern muss laufen. Wer im Alltag noch Löcher stopft, hat für solche Fragen keinen Kopf.

Welche Grenze in deinem Bereich ist eigentlich nur Gewohnheit?

## 05 · So 18.10. · Geschichten aus der Praxis · Satz

Bild: rp10.jpg · Satz · B Anführungszeichen

„Das habe ich noch nicht richtig verstanden. Können Sie mir das mal in Ihren eigenen Worten erklären?“

Diesen Satz habe ich von meinem Vorstand unzählige Male gehört. Meist in Meetings, in denen wichtige Folien gezeigt und wichtige Worte benutzt wurden.

Das Bemerkenswerte: Er hatte es fast immer längst verstanden.

Er wollte wissen, ob derjenige es verstanden hat, der das Thema präsentiert und nachher umsetzen soll.

Denn das Thema muss auch dann richtig weiterlaufen, wenn der Vorstand nicht mehr im Raum ist.

Seine kleine Mikromethode. Ganz ruhig, ohne jede Schärfe. Und jedes Mal hat sie gezeigt, ob ein Thema trägt.

Ich bewundere sie bis heute.

Für beide Seiten des Tisches steckt etwas drin:

• Wer führt, hat eine Frage, die mehr prüft als jeder Statusbericht.
• Wer präsentiert, weiß, worauf es ankommt: das Thema in eigenen Worten erklären können, ohne Folie.

## 06 · Mo 19.10. · Branche eingeordnet · Eingeordnet · B Zahl auf Foto

Bild: rp08.jpg · Eingeordnet · B Zahl auf Foto

77 % sagen: Das Tagesgeschäft verdrängt die strategischen Projekte. Nur 11 % sagen, die Mitarbeitenden verstehen die Strategie.

Die Zahlen stammen aus einer branchenübergreifenden Studie von Wieselhuber. Bei Versicherern erlebe ich es nicht anders.

Was heißt das für einen Bereich? Strategie braucht im Alltag einen festen Platz, sonst gewinnt immer das, was heute brennt.

Zwei Dinge helfen.

Jeder kann in einem Satz sagen, wohin der Bereich will und warum, dann lassen sich Prioritäten im Alltag selbst entscheiden.

Und strategische Themen bekommen feste Termine im Kalender, genauso wie das Tagesgeschäft.

## 07 · Di 20.10. · 01 Strategie im Alltag · Szene · B Foto mit Satz

Bild: rp01.jpg · Szene · B Foto mit Satz

Ich erlebe es immer wieder: Eine neue Strategie soll her, und der erste Schritt ist ein großer Workshop mit dem ganzen Team. Alle sollen mitreden, alle sollen sich wiederfinden.

In der Praxis holst du damit Menschen an den Tisch, die nie gelernt haben, über Strategie zu sprechen, und denen die Erfahrung dafür fehlt.

Heraus kommt ein Kompromiss, auf den sich alle einigen können. Schlechtes Mittelmaß.

Nebenbei entsteht Unsicherheit. Wenn der Chef fragt, wo es hingehen soll, wirkt es, als wüsste der Trainer nicht, wohin die Mannschaft laufen soll.

Die Reihenfolge ist eine andere. Zuerst klärt die Führungskraft, wo der Bereich hinwill und wie er dort erfolgreich ist.

Der Einstieg beginnt dabei nicht mit einem Zweitagesworkshop. Zwei, drei Gespräche mit mir reichen, um den Gesamtzusammenhang klar und stringent zu skizzieren.

Diesen arbeiten wir danach gezielt aus, immer nur in dem zeitlichen Umfang, den es braucht. Zwischen den Terminen arbeite ich weiter und liefere das nächste Level der Ausarbeitung.

Wer oben steht und selbst kein Bild hat, wohin es geht, kann das von seinen Führungskräften auch nicht verlangen.

## 08 · Mi 21.10. · 02 Komplexe Themen · Modell · A Why · How · Next

Bild: rp02.jpg · Modell · A Why · How · Next

„Danke. Bitte bereiten Sie das noch einmal auf.“

Drei Wochen Arbeit. Zwanzig Minuten Vorstand. Ein Satz.

Und du gehst raus und fragst dich, was du falsch gemacht hast.

Ich sage es dir ehrlich: Am Thema lag es nicht. Du hast zu viel gewusst. Und alles erzählt.

Wer sein Thema richtig gut kennt, kann am schlechtesten weglassen. Jedes Detail fühlt sich wichtig an. Ist es auch. Nur nicht für diese eine Entscheidung.

Der Vorstand denkt in dem Moment nicht: schwaches Thema. Er denkt: Was soll ich damit jetzt machen?

Er will drei Dinge wissen. Mehr nicht.

Why?
Was bedeutet das Thema für unser Unternehmen?

How?
Wie gehen wir grundsätzlich vor, um das Ergebnis zu erreichen? Die Details will er erst sehen, wenn er Ja gesagt hat.

What next?
Was muss heute entschieden werden, damit es weitergeht?

Drei Fragen, drei Sätze. Bekommst du die nicht hin, retten dich auch keine vierzig Folien.

## 09 · Do 22.10. · 01 Strategie im Alltag · Szene · B Foto mit Satz (Porträt)

Bild: rp03.jpg · Szene · B Foto mit Satz (Porträt)

Du stellst in der Runde eine Idee vor. Alle nicken. Du fragst: „Sieht das jemand anders?“ Stille.

Je höher du kommst, desto seltener sagt dir jemand ins Gesicht, was er denkt.

Mit Budget und Karriere hat das nur am Rande zu tun. Ab einer gewissen Stufe ist da Ehrfurcht.

Viele glauben, einem Vorstand oder einem Hauptabteilungsleiter dürfe man gar nicht die Wahrheit sagen. Und sie sind schlicht unsicher.

Was dir dann fehlt, ist ein Mensch auf Augenhöhe. Jemand, der
• eine andere Perspektive einnimmt und sie gut begründen kann.
• gezielte Fragen stellt, die dich wirklich zum Nachdenken bringen und dir einen anderen Blick auf die Dinge geben.
• Gesamtzusammenhänge aufzeigt und den nächsten Schritt klar benennt.

Schreibe dir heute einen Namen auf:
Wer sagt dir die Wahrheit? Ungeschönt, ohne Rücksicht auf deine Position.

Fällt dir niemand ein, ist das die wichtigste Aufgabe dieser Woche.

## 10 · Fr 23.10. · 01 Strategie im Alltag · Frage · E Skala

Bild: rp04.jpg · Frage · E Skala

Im Alltag kommt ständig etwas hoch: ein dringender Sachverhalt, eine Vorstandsbeschwerde, ein Termin, der brennt. Das muss heute geregelt werden.

Gleichzeitig steht irgendwo eine Strategie, die erreicht werden soll.

In Bereichen, in denen Strategie wirkt, ist beides sauber getrennt. Dort ist jederzeit klar, womit man sich beschäftigt und womit nicht, damit die Strategie umgesetzt wird.

Ein ehrlicher Test für diese Woche: Gehe deinen Kalender durch und markiere jeden Termin, der direkt auf die Strategie einzahlt. Der Rest ist Tagesgeschäft.

Das Verhältnis zeigt dir, wo du ansetzen musst.

Und wenn dir beim Markieren nicht klar ist, was auf deine Strategie einzahlt, dann ist die Strategie nicht klar genug.

## 11 · Sa 24.10. · 03 Geschäftsmodell · Weitergedacht

Bild: rp11.jpg · Weitergedacht · Gelbe Satzkarte

Diesen Satz habe ich letzte Woche gefühlt zehnmal gehört – von der Anwaltshotline meiner Rechtsschutzversicherung.

Ich hatte ein konkretes Thema und wollte eine Grundeinordnung. Keine abschließende Bewertung, dafür muss man in die Verträge schauen, das ist mir klar. Genau das habe ich gleich zu Beginn gesagt.

Ich wollte eine Denkhilfe für das Gespräch mit meinem Vertragspartner. Eine Richtung.

Bekommen habe ich: Verträge prüfen. Erst mit dem Vertragspartner reden. Wenn das nicht weiterhilft, anwaltlich prüfen lassen.

Keine Einordnung. Keine Richtung. Das Gespräch hätte ich mir sparen können.

Was mich daran ärgert, ist die vergebene Chance. Versicherer können ihre Leistung meistens nur im Schadenfall zeigen. Ein Rechtsschutzversicherer hat mit so einer Hotline etwas, das sich andere wünschen: mehr Kontakte mit dem Kunden, bei denen er ein echtes Problem löst.

Beim Abschluss wird genau dieser Service groß angepriesen. Und in dem Moment, in dem ich ihn brauche, bekomme ich nicht einmal eine Richtung.

Ein Feature, das im entscheidenden Moment nicht hält, was es verspricht, schadet mehr, als wenn es gar nicht da wäre.

Wer Services verantwortet, die beim Abschluss verkauft werden: Wann hat zuletzt jemand geprüft, was davon im Ernstfall beim Kunden ankommt?

## 12 · So 25.10. · 01 Strategie im Alltag · Aufgegriffen · Foto mit Satz

Bild: rp12.jpg · Aufgegriffen · Foto mit Satz

„Gute Beratung führt nicht möglichst schnell zu einer Lösung. Gute Beratung führt Schritt für Schritt zu einer begründeten Entscheidung.“

Das hat Matthias Weber, Vertriebsvorstand bei HDI Bancassurance, in seiner Montagskolumne geschrieben. Den Satz unterschreibe ich sofort.

Sein Punkt: Die Regulierung setzt den Rahmen. Den Unterschied macht, wie wir ihn mit Leben füllen.

Wie es aussieht, wenn das keiner tut, habe ich gestern erzählt. Anwaltshotline, konkrete Frage, und als Antwort immer wieder „Das kommt darauf an“. Formal alles richtig. Weitergekommen bin ich keinen Schritt.

Und genau das erlebe ich in den Häusern auch nach innen. Die Regel wird zur Begründung, warum etwas nicht geht. Keiner traut sich, eine Richtung zu geben, weil er Angst hat, sich festzulegen.

Wenn du Vertrieb oder Service führst, kannst du deinen Leuten genau hier richtig viel abnehmen.

Sie müssen wissen, wo die Grenze verläuft. Und was sie bis dahin klar sagen dürfen, ohne sich dreimal abzusichern.

Wer das weiß, gibt dem Kunden eine Richtung. Und genau dafür ruft er an.

## 13 · Mo 26.10. · 03 Geschäftsmodell · Frage · C Fragezeichen

Bild: rp13.jpg · Frage · C Fragezeichen

Diese Frage stelle ich ziemlich früh, wenn es um die Zukunft eines Bereichs geht. Und die Antwort sieht jedes Mal anders aus als das, was heute da ist.

Zuständigkeiten, Abläufe, Schnittstellen: Vieles ist einfach so gewachsen. Also baut man weiter auf dem, was da ist. Wer neu gründet, darf all das infrage stellen.

Erst wenn das Bild steht, reden wir über Strategie. Ohne dieses Bild gibt es keine gescheite Strategie. Mit ihm ergibt sie sich fast von allein. Sie ist dann der Weg von heute dorthin.

Damit aus der Frage keine Wunschliste wird, gehe ich drei Dinge durch:

• Welches Problem hat dein Kunde wirklich?
• Wie löst du es?
• Und ist er überhaupt bereit, es zu lösen?

Einen Rat gebe ich dabei jedes Mal mit: Beantworte die Frage zuerst allein.

Stellst du sie gleich deinem ganzen Team, fragt sich jeder zuerst, ob es seinen Job danach noch gibt. Und mit dieser Sorge im Kopf denkt keiner frei.

## 14 · Di 27.10. · 01 Strategie im Alltag · Szene · A Foto mit Satz

Bild: rp14.jpg · Szene · A Foto mit Satz

Als ich selbst eine Abteilung geführt habe, rund 40 Leute an zwei Standorten, habe ich eine Sache gründlich unterschätzt.

Ich dachte: Wenn die Logik stimmt, läuft der Rest. Saubere Prozesse, klare Regelungen, ordentliche Absprachen.

Das hat nicht gereicht. Nicht annähernd.

Menschen sind im Alltag viel ausgeprägter, als es jedes Persönlichkeitsmodell beschreibt. Und unter Führungskräften laufen Strömungen, die in keinem Organigramm stehen: wer welche Interessen verteidigt und wer worauf Einfluss hat.

An vielen Stellen hast du mit reiner Logik fast keine Chance.

Was wirkt, ist Führung im Alltag. Kein Mikromanagement. Aber so aufgestellt sein, dass deine Leute merken: Da ist jemand, der Richtung gibt, nachhält und entscheidet.

Bevor du die nächste Regel aufschreibst, stelle dir zwei Fragen:

• Wer muss sich dafür im Alltag anders verhalten?
• Und woran merkt er, dass es dir ernst ist?

## 15 · Mi 28.10. · 02 Führung · Modell · D Drei Kreise

Bild: rp15.jpg · Modell · D Drei Kreise

Gestern noch der stärkste Sachbearbeiter im Team. Heute Gruppenleiter. Glückwunsch, Blumen, Mail an alle.

Und dann? Nichts.

Man gibt ihm zwölf bis vierundzwanzig Monate, um hineinzuwachsen. In der Zeit läuft er im Alarmmodus: geerbte Regeltermine, unbesetzte Stellen, Löcher stopfen.

Nach einem Jahr heißt es: „Von dem hätten wir uns mehr erwartet.“

Das finde ich ganz schlimm. Am Können liegt es fast nie. Ihm fehlt das System, mit dem er das Spiel überhaupt gewinnen kann.

Bevor du das nächste Mal jemanden beförderst, kläre vorher mit ihm drei Dinge:

1. Was erwartet das Haus von dieser Rolle? In klaren Worten.
2. Wie nimmt er sein Team mit?
3. Wie trägt sein Bereich zum Erfolg des Unternehmens bei?

Eine Stunde vor dem ersten Tag. Nicht ein Jahr danach.

## 16 · Do 29.10. · Geschichten aus der Praxis · Du als Person · Foto

Bild: rp16.jpg · Du als Person · Foto

Im Sommer 2025 stand ich wieder vor dem Lloyd's Building. 25 Jahre nach meiner Zeit in der Londoner Rückversicherung.

Ich kam damals von einem ganz normalen Versicherer aus Stuttgart. Schulungen weit weg, Budget knapp.

In London war das anders. Alle Häuser saßen im selben Viertel.

Kam ein neues Thema hoch, nahm es sich eine Firma, bereitete es auf und lud ein. Kurzer Impuls nach Feierabend, danach Essen und Trinken.

Man konnte sich praktisch jeden Tag weiterbilden. Über die Grenzen der eigenen Firma hinaus.

Das habe ich mitgenommen. Zurück in Deutschland wurde daraus „90 Minuten Wissen to go“. Das Format läuft bei meinem früheren Arbeitgeber bis heute.

Das Rezept ist simpel:

1. Ein aktuelles Thema.
2. Jemand, der es kurz auf den Punkt bringt.
3. Danach Zeit zum Reden.

Mehr braucht es nicht, damit Wissen im Haus wandert.

## 17 · Fr 30.10. · 02 Komplexe Themen · Frage · Suchergebnis 0

Bild: rp29.jpg · Frage · Suchergebnis 0

Zwei Tage lang habe ich DKM-Beiträge gelesen. Ich weiß immer noch nicht, was in Dortmund eigentlich passiert ist.

Ich war dieses Jahr nicht dabei. Also bin ich auf euch angewiesen. Und lese überall:
• toller Austausch
• super Impulse
• absolutes Highlight

Schön. Aber was genau?

Darum meine Frage an alle, die dort waren: Was macht ihr ab Montag anders, weil ihr dort wart?

Ein Satz, eine Idee, ein Gespräch reicht.

Oder war es einfach schön, dabei gewesen zu sein? Darf man auch zugeben.

Ich lese jede Antwort.

## 18 · Sa 31.10. · 03 Geschäftsmodell · Weitergedacht · Foto

Bild: rp18.jpg · Weitergedacht · Foto

Unsere Werkstudenten kamen nicht über eine Anzeige. Sie saßen montags um 8 Uhr in meiner Vorlesung.

Die Vorgeschichte: 2017 gingen die guten Leute in Stuttgart zu den großen Autobauern, Beratungen und Banken. Zu uns kleinem Haus kam kaum jemand.

Eine Ausschreibung allein bringt dich da nicht weiter.

Über einen Bekannten kam der Kontakt zur Macromedia. Angeboten hatte ich einen Gastvortrag. Am Ende hatte ich die ganze Vorlesung.

Montags um 8 Uhr, auf Englisch. Für einen Nachtmenschen wie mich eine echte Prüfung.

Das Fach habe ich bewusst gewählt: Projektmanagement. Da konnte ich die Leute, die sich hervortun, später auch brauchen.

Zwei haben mich direkt gechallenged. Kurz darauf waren sie unsere Werkstudenten. Mit einem bin ich bis heute befreundet.

Wo hast du gerade einen strukturellen Nachteil? Und wohin müsstest du gehen, um ihn umzudrehen?

## 19 · So 01.11. · 03 Geschäftsmodell · Aufgegriffen · Zitatkarte

Bild: rp19.jpg · Aufgegriffen · Zitatkarte

Bei KI stellt die Branche meistens die falsche Frage. Tobias Knörrer, Geschäftsführer der bbg, hat vor der DKM die richtige gestellt. Sie steht im Bild.

Bei KI fragt die Branche meistens: Wie setzt der Makler KI ein? Er dreht das um: Welche Leistungen brauchen Kunden in zehn Jahren überhaupt noch?

Seine Antwort für Makler: das Urteil bei unvollständiger Information, die Fähigkeit, einen Kunden zu einer Entscheidung zu bewegen, und die Haftung für das Ergebnis.

Die Frage gehört in jeden Versicherer. In jeden einzelnen Bereich.

So gehst du sie an:

1. Schreibe auf, welche Leistungen ihr heute erbringt.
2. Markiere, was euer Kunde in zehn Jahren noch braucht.
3. Sieh dir den Rest ehrlich an.

Was übrig bleibt, gibt es oft nur, weil es schon immer da war.

## 20 · Mo 02.11. · 01 Strategie im Alltag · Szene · Postfach-Nachbau

Bild: rp27.jpg · Szene · Postfach-Nachbau

Wenn ein anderes Team nicht mitzieht, liegt es fast nie an diesem Team.

Du schreibst die dritte Mail. Du hast die Unterlagen nachgeschärft. Und das andere Team zieht trotzdem nicht mit.

Ich kenne das. Es nervt.

Der naheliegende Schluss: Die wollen nicht. Also braucht es eine Maßnahme mit dem Team.

Wenn ich in solchen Fällen genauer hinschaue, ist es fast immer etwas anderes.

Die Rollen sind nicht geklärt. Das Zielbild fehlt. Oder die anderen haben schlicht keinen Auftrag mitzumachen.

Der letzte Punkt tut am meisten weh: Nur weil du etwas willst, muss der andere Bereich nicht mitmachen. Er wird nach seinen eigenen Zielen gesteuert.

Bevor du die vierte Mail schreibst:

1. Finde heraus, woran das andere Team gemessen wird.
2. Prüfe, ob dein Thema darauf einzahlt.
3. Wenn nicht: Kläre es eine Ebene höher.

## 21 · Di 03.11. · 02 Komplexe Themen · Szene · B Foto mit Satz

Bild: rp21.jpg · Szene · B Foto mit Satz

Bessere Unterlagen retten kein Produkt, an dem dein Partner nichts verdient.

„Warum nimmt die Bank unser Vertriebskonzept nicht an?“

Diese Frage höre ich regelmäßig. Und gleich danach die Ideen: noch ein Impuls, bessere Unterlagen, eine Schulungsrunde. Notfalls Druck.

Setze dich gedanklich einmal auf die andere Seite des Tisches.

Für die Bank sieht es oft so aus:

• zu wenig Ertrag
• zu wenige Leute, die das Thema verstanden haben
• eine Systemanbindung, die jeden Abschluss zum Ärgernis macht

Dann kannst du die Unterlagen noch so schön machen.

Ich verstehe den Wunsch, dass es dann läuft. Funktionieren wird es trotzdem nicht.

Bevor die nächste Unterlage entsteht, beantworte drei konkrete Fragen:

1. Wie mache ich mein Gegenüber erfolgreich?
2. Wie vermeide ich unnötigen Aufwand?
3. Was ist der konkrete nächste Schritt zur Umsetzung?

Was würdest du als Vertreter der Bank von einem Versicherer erwarten?

## 22 · Mi 04.11. · 01 Strategie im Alltag · Werkzeug · Dokument-Karussell (5 Seiten)

Bild: ka1.jpg · Werkzeug · Dokument-Karussell (5 Seiten)

Für den Einstieg in eine Strategie brauchst du keine zwei Tage Workshop. Drei Stunden reichen.

Die meisten Führungskräfte denken bei Strategie sofort an Moderationskoffer und Kärtchen an der Wand. Ich brauche zwei, drei Gespräche à eine Stunde. Am Telefon.

Du bereitest nichts vor. Keine Folien. Du erzählst, was dir durch den Kopf geht. Ich frage, unterbreche, frage weiter.

Dann lege ich dir hin, was ich gehört habe. Strukturiert, neben der Logik des Geschäftsmodells Versicherung.

Das ist der Moment, auf den ich hinarbeite: Plötzlich steht da ein Bild, das du die ganze Zeit im Kopf hattest.

Danach klären wir, wen es braucht und wie die Betroffenen ticken. Erst dann geht es los.

Den ersten Schritt kannst du heute selbst machen:

Erzähle jemandem, dem du vertraust, eine Stunde lang ohne Unterlagen, wo dein Bereich hin soll. Und bitte ihn, dir zu spiegeln, was er verstanden hat.

## 23 · Do 05.11. · Geschichten aus der Praxis · Geschichte · Foto

Bild: rp23.jpg · Geschichte · Foto

In fast jedem meiner Termine kommt ein Moment, ab dem keiner mehr diskutiert.

Mir selbst ist das lange nicht aufgefallen. Eine Mitarbeiterin hat es mir gespiegelt: Meine Termine laufen im Kern immer gleich.

Ich frage und zeichne mit. Irgendwann sage ich: „Eigentlich ist es doch so.“

Dann steht die Struktur auf dem Flipchart oder dem iPad. Ab da sieht jeder den Gesamtzusammenhang, und die Diskussion dreht sich nicht mehr im Kreis.

Das kannst du auch:

1. Frage so lange, bis du die Abhängigkeiten siehst.
2. Sortiere, was Überbegriff ist und was Detail. Wie im Kinderrätsel: Apfel, Birne, Kirsche, Obst.
3. Zeichne das Ganze auf ein einziges Blatt.

Wenn du den Satz sagen kannst, hast du das Thema verstanden. Und die anderen auch.

## 24 · Fr 06.11. · 01 Strategie im Alltag · Zum Mitnehmen · Gedankenexperiment

Bild: rp24.jpg · Zum Mitnehmen · Gedankenexperiment

Ob dein Bereich ein Zielbild hat, erkennst du an einer Homepage, die es gar nicht gibt.

Deine Abteilung wird morgen ausgegründet. Eigene GmbH. Sie verkauft ihre Leistung an deinen bisherigen Arbeitgeber.

Was steht auf eurer Homepage?

• Wofür seid ihr da?
• Welches Problem löst ihr für wen?
• Warum sollte das Haus euch beauftragen und es nicht selbst machen?

Jetzt die eigentliche Probe: Würde jeder in deinem Team dasselbe hineinschreiben?

Wenn ja, habt ihr ein Zielbild. Wenn nicht, weißt du, woran du die nächsten Wochen arbeitest.

So geht die Übung: Schreibe deine Fassung allein. Bitte drei Leute aus dem Team, dasselbe zu tun, ohne deine zu kennen. Dann legt ihr alles nebeneinander.

Spätestens dann wird es interessant.

## 25 · Sa 07.11. · 03 Geschäftsmodell · Weitergedacht · Foto

Bild: rp25.jpg · Weitergedacht · Foto

Drei Sätze verhindern mehr Neues als jedes fehlende Budget.

„Das war schon immer so.“
„Das ist bei uns gesetzt.“
„Das macht man in unserer Branche nicht.“

Drei Sätze, die ich höre, sobald es um das Geschäftsmodell von morgen geht.

Jeder ist verständlich. Und jeder nimmt eine Möglichkeit vom Tisch, bevor jemand darüber nachgedacht hat.

Ein kleiner Test fürs Wochenende:

1. Nimm eine Sache aus deinem Bereich, die als gesetzt gilt.
2. Stelle dir vor, es gäbe sie ab morgen nicht mehr.
3. Frage dich: Wer würde es merken? Was würde wirklich fehlen?

Bei manchen Dingen ist die ehrliche Antwort: niemand. Nichts.

Genau dort fängt Neudenken an.

## 26 · So 08.11. · 01 Strategie im Alltag · Aufgegriffen · Zitatkarte

Bild: rp26.jpg · Aufgegriffen · Zitatkarte

Mut, Führung, Tempo. Steht in jeder Strategie. Und scheitert im Alltag an drei banalen Stellen.

Peter Stockhorst, Digitalvorstand der Zurich Gruppe Deutschland, hat im Frühjahr genau das gefordert. Sein Satz steht im Bild. Ich unterschreibe ihn.

Die drei Stellen:

• Es gibt kein klares Bild, wo es hingehen soll. Dann ist jede Initiative gleich wichtig.
• Keiner entscheidet, was wegfällt. Also läuft alles parallel.
• Zwischen den Terminen passiert nichts. Das Thema wartet auf den nächsten Jour fixe.

In den Vorstandsklausuren, die ich vorbereitet habe, kam Bewegung immer dann, wenn einer in den Lead ging. Bedeutung klar, Richtung gesagt, los.

Deine Aufgabe für Montag: Schreibe deine laufenden Initiativen auf. Streiche drei. Und sage laut, wer die übrigen treibt.

## 27 · Mo 09.11. · Geschichten aus der Praxis · Frage · Foto

Bild: rp30.jpg · Frage · Foto

Das erste Projekt bei einem Kunden bestimmt, in welcher Schublade du dort für Jahre steckst.

Bei einem Kunden habe ich vor Ewigkeiten ein Seminar gehalten.

Daraus wurden viele Themen, die wir ganz neu aufgesetzt haben. Heute machen wir dort vor allem Strategieprojekte.

Ein Vorstand dort fragt mich trotzdem jedes Mal, welches Seminar ich heute leite.

Bei einem anderen Kunden ging es im ersten Projekt um Prozesse. Seitdem sind wir dort die Prozessoptimierer.

Ich finde das eher lustig. Und es ist zutiefst menschlich.

Im eigenen Haus geht es dir nicht anders. Mit dem Thema, mit dem du in deiner Rolle gestartet bist, verbinden dich viele bis heute.

In welcher Schublade steckst du gerade? Und welche wäre die richtige?

## 28 · Di 10.11. · 02 Komplexe Themen · Szene · Zitatkarte (Film)

Bild: rp28.jpg · Szene · Zitatkarte (Film)

In einer Minute dieses Spionagefilms lernst du mehr über Vertrieb als in jedem Vertriebsseminar.

In „Der Spion“ sitzt Benedict Cumberbatch in seiner Rolle als Geschäftsmann mit potenziellen Kunden am Tisch und sagt sinngemäß:

„Ich vertrete die besten Hersteller. Ihr kennt euer Geschäft. Also spare ich mir die übliche Show und höre zu. Habe ich eine Lösung, reden wir. Wenn nicht, trinken wir weiter.“

Sensationell.

Jetzt vergleiche das mit dem typischen Vertriebstermin: zwanzig Minuten Produkt, dann Konditionen, dann „Noch Fragen?“.

Er macht drei Dinge anders:

• Er ist so überzeugt von seinem Angebot, dass er es nicht erklären muss.
• Ihn interessiert nur das Problem des Kunden.
• Er verkauft nur, wenn es wirklich passt – und sagt das offen.

Das spürt jeder Kunde: Hier will mir keiner etwas andrehen.

Für deinen nächsten Termin:

1. Die ersten zehn Minuten kein Wort über dein Produkt.
2. Eine Frage: Was beschäftigt euch gerade?
3. Und den Mut zu sagen: Dafür habe ich nichts.

Ab diesem Satz glaubt man dir den Rest.

## 29 · Mi 11.11. · Geschichten aus der Praxis · Werkzeug · Bildschirm

Bild: rp31.jpg · Werkzeug · Bildschirm

Wenn ein Kunde mir seine fertigen Folien zeigt, wandern sie bei mir erst einmal alle ins Backup.

Die Fakten darauf stimmen meistens.

Nur sprechen die Folien über das eigene Thema, mit allen Details. Was der Adressat davon hat, steht nirgends.

Für mich selbst baue ich übrigens gar keine PowerPoints. Für Kunden baue ich sehr viele.

Ich arbeite mit einem Gesamtbild: handgezeichnet in OneNote oder als One-Pager, durch den ich strukturiert durchgehe.

Erst das Ganze, dann die Details.

So gehst du vor, bevor die erste Folie entsteht:

1. Bringe das Gesamtbild auf eine Seite.
2. Schreibe darunter, was der Adressat danach entscheiden soll.
3. Prüfe jede alte Folie: Hilft sie genau dabei?

Was nicht hilft, bleibt im Backup. Meistens ist das der größte Teil.

## 30 · Do 12.11. · Geschichten aus der Praxis · Geschichte · Satzpaar

Bild: rp32.jpg · Geschichte · Satzpaar

Drei Führungskräfte wollten von mir ein Konfliktseminar. Ich habe ihnen kein Angebot geschrieben.

Erst wollte ich verstehen, woher die Konflikte kommen. Nach ein paar Fragen war es klar: Keiner wusste, wo der Bereich hinsoll.

Ohne Zielbild legt jeder den Alltag anders aus. Und es gibt keinen Maßstab, an dem man sagen kann: Das ist die Richtung.

Dann streitet man eben. Ein Seminar ändert daran nichts.

Also haben wir an Zielbild und Rollen gearbeitet. Die drei hatten schnell Handlungssicherheit, und die Konflikte wurden weniger.

Mein schönster Moment: Im ersten Termin hörte ich „Ich bin Projektleiter, keine Führungskraft.“

Im vierten Termin sagte dieselbe Person ganz selbstverständlich: „In meiner Rolle als Führungskraft …“

Wenn bei dir ständig Konflikte hochkommen, prüfe zuerst:

1. Kann jeder sagen, wo der Bereich hinsoll?
2. Ist klar, wer was entscheidet?
3. Gibt es einen Maßstab, wer im Streit recht hat?

Fehlt das, hilft dir kein Seminar.

## 31 · Fr 13.11. · Werkstatt · Werkstatt · Foto

Bild: rp17.jpg · Werkstatt · Foto

Ich habe in diesem Jahr die KI angeschrien. Mehrfach.

Seit über einem Jahr bringe ich mir nun bei, wie Agenten und Automatisierungen wirklich funktionieren. Das hat mich schon Nächte gekostet und Nerven wie selten etwas.

Immer wenn ich dachte, jetzt habe ich es raus, kam wieder nur Mist.

Es gab keinen Aha-Moment, nach dem alles lief. Es ging Stufe für Stufe. Ausprobieren, scheitern, neu ansetzen.

Dass mich die KI nervt, geht bis heute nicht ganz weg.

Mindestens genauso nervt mich inzwischen etwas anderes.

Runden zum Thema „Wie setzen wir KI ein?“, in denen Leute sitzen, die ganz offensichtlich keinerlei Erfahrung damit haben.

Das ist, als würde der Blinde von der Farbe sprechen. Nur geht es hier um die Zukunft des Unternehmens.

Wenn du mitreden willst:

1. Fange klein an, mit einem Tool, das ihr nutzen dürft.
2. Nimm jede Woche eine echte Aufgabe dazu.
3. Rechne damit, dass es oft nicht klappt. Und bleibe dran.

Ganz verstanden hast du es nie. Aber du weißt, worüber du redest.

## 32 · Sa 14.11. · Geschichten aus der Praxis · Person · Foto

Bild: rp33.jpg · Person · Foto

Das schönste Lob für meine Erklärungen bekomme ich von den Freundinnen meiner Tochter.

Sie ist in der 8. Klasse, und wir lernen zusammen Mathe. Ich bin wirklich kein Mathe-Profi.

Aber Mathe in der Mittelstufe heißt im Kern: das System erkennen und den Weg finden, der eine scheinbar komplizierte Aufgabe einfach macht.

Inzwischen lernt sie begeistert Mathe. Und ihre Freundinnen fragen, ob ihr Papa wieder einen coolen Trick hatte.

Für mich ist das die höchste Auszeichnung.

So gehe ich am Küchentisch vor:

1. Zuerst zeigen, worauf die Aufgabe hinausläuft.
2. Den einen Weg erklären, der immer funktioniert.
3. Sie selbst einmal durchrechnen lassen.

Am Montag im Besprechungsraum mache ich übrigens genau dasselbe.

Gut erklärt hast du, wenn andere nachfragen, wie das geht.

## 33 · So 15.11. · Geschichten aus der Praxis · Szene · Anruf

Bild: rp34.jpg · Szene · Anruf

„Daniel, ich brauche dich mal nur ganz kurz.“

Wenn ein Vorstand so anruft, weiß ich: Gleich kommt eine Lage, die jemand sortieren muss.

In diesem Fall ging es um die Zusammenlegung zweier Abteilungen zu einer neuen Hauptabteilung.

Aus dem kurzen Andiskutieren wurde eine Stunde Sparring. Danach war klar: Hier bleiben wir dran.

Zusammenlegen ist schnell entschieden. Dass der neue Zuschnitt gelebt wird, dauert deutlich länger.

Die eigentliche Arbeit war, dass der neue Bereich funktioniert, intern und an jeder Schnittstelle im Haus.

Wenn du gerade zusammenlegst, kläre vier Dinge, bevor Rollen auf Papier stehen:

• Wofür ist der neue Bereich da?
• Was macht er ausdrücklich nicht?
• Wo hat jeder Einzelne seinen Platz?
• Wer im Haus muss den Zuschnitt kennen?

Sonst arbeiten zwei Abteilungen unter neuem Namen weiter wie bisher.

## 34 · Mo 16.11. · Geschichten aus der Praxis · Werkzeug · Videokonferenz

Bild: rp35.jpg · Werkzeug · Videokonferenz

„Kann mir einer kurz einordnen, mit welchem Ergebnis wir heute rausgehen wollen?“

Mit dieser Frage beginne ich fast jede Videokonferenz.

Kommt ein kurzes Gesamtbild und ein klares Ergebnis, ist alles gut.

Kommen vorbereitete Einzelpunkte oder die Agenda, weiß ich: Hier klammert sich jemand an sein Thema.

Dann sage ich: Wenn das nicht klar ist, brauchen wir über das hier heute gar nicht zu sprechen.

Danach folgt meistens eine muntere Diskussion, was eigentlich das Ziel ist. Das ist für alle okay. Sie wollen ja etwas erreichen.

Dein Test für diese Woche:

1. Stelle die Frage zu Beginn jedes Termins.
2. Achte darauf, wer sie in zwei Sätzen beantworten kann.
3. Kann es keiner, klärt ihr zuerst das Ziel und dann das Thema.

## 35 · Di 17.11. · 01 Strategie im Alltag · Szene · Mitteilungen

Bild: rp36.jpg · Szene · Mitteilungen

Erst verbieten Vorstände fast jede KI im Haus. Dann fordern sie von ihren Leuten KI-Schnellboote.

Das erlebe ich gerade in vielen Häusern.

Es gibt eine Taskforce, eine zentrale KI-Einheit und eine lange Liste, was noch geregelt werden muss. Erlaubt ist im Moment sehr wenig.

Gleichzeitig hören die Leute in jeder Rede: Denkt über den Tellerrand. Bringt Ideen. Setzt KI ein.

Das passt nicht zusammen. Und es nervt mich, weil die Leute genau merken, dass es nicht zusammenpasst.

Was dann passiert: Viele nutzen privat, was im Job nicht erlaubt ist. Und schicken sich das Ergebnis per Mail ins Büro.

Wenn du Schnellboote willst, brauchst du drei Dinge:

1. Eine klare Aussage, wofür KI im Haus da sein soll.
2. Einen Rahmen, in dem ein kleines Team ausprobieren darf.
3. Nach drei Monaten die Frage, was es gelernt hat.

Wer Ausprobieren fordert, muss Ausprobieren erlauben.

## 36 · Mi 18.11. · Geschichten aus der Praxis · Modell · Dokument

Bild: rp37.jpg · Modell · Dokument

Sechs Vorstände, sechs Charaktere, eine mehrtägige Klausur.

Bei jedem wichtigen Thema kam irgendwann ein einziger Satz, der die Richtung vorgab.

Ich habe solche Klausuren in der Konzernstrategie vorbereitet. Alle sechs waren hochintelligent und erfahren.

Aus diesem einen Satz konnte jeder ableiten. Und jeder konnte später sein Thema daran messen. Das war mehr wert als jedes Management Summary.

Gekippt sind Diskussionen immer dann, wenn nicht klar war, was ein Thema für das Unternehmen bedeutet.

Je mehr der zuliefernde Bereich auf Details gepocht hat, desto schlechter lief es.

Für deine nächste Vorlage:

1. Schreibe die Grundrichtung in einen Satz.
2. Schreibe darunter, was das Thema für das Unternehmen bedeutet.
3. Streiche jedes Detail, das an dieser Bedeutung nichts ändert.

Passt dein Satz nicht in eine Zeile, ist die Richtung noch nicht klar.

## 37 · Do 19.11. · Geschichten aus der Praxis · Geschichte · Foto

Bild: rp38.jpg · Geschichte · Foto

Zweimal wurde mir schon gedroht, dass ich im Konzern nie wieder einen Auftrag bekomme. Ich habe beide Male Nein gesagt.

Es waren Menschen, mit denen ich vorher erfolgreich gearbeitet hatte.

Sie wollten, dass es endlich nach vorne geht, und sahen mich als Lösung.

Nur wusste ich: So, wie der Auftrag gedacht war, funktioniert er nicht.

Vielleicht hatten sie selbst riesigen Druck. Das verstehe ich.

Trotzdem hilft so ein Auftrag keinem. Am Ende scheitert das Thema, und es heißt: „Siehst du, der hat es auch nicht hingekriegt.“

Die Leute, die im Thema drinsitzen, verbrennst du gleich mit.

Ich übernehme Aufträge, bei denen ich weiß, wie wir zum Ergebnis kommen.

Bei allen anderen sage ich klar, dass ich der Falsche bin, und nenne, wer es besser kann. Die meisten nehmen das dankend an.

Bevor du das nächste Mal Ja sagst, frage dich:

1. Weiß ich, wie das zum Ergebnis kommt?
2. Bin ich dafür der Richtige?
3. Wen verbrenne ich, wenn es scheitert?

## 38 · Fr 20.11. · Geschichten aus der Praxis · Geschichte · Foto

Bild: rp39.jpg · Geschichte · Foto

Die besten fünf Minuten der Vertriebstagung hatte jemand, der gar nicht auf der Agenda stand.

Wir hatten die Tagung mit vorbereitet.

Unsere Bitte von Anfang an: so nah wie möglich an den Alltag der Agenturleiter. Was bringt mir das, was mache ich morgen damit?

Dagegen hieß es immer: Die fachlichen Neuerungen sind wichtiger. So kam es dann auch.

Dann stellte jemand im Saal eine Frage.

Der Referent gab sie an eine Person im Publikum weiter, die genau das in der eigenen Agentur sehr gut umsetzt.

Sie ging auf die Bühne und erzählte fünf Minuten. Ohne Präsentation.

Thema eingeordnet, Alltag gezeigt, jeder Satz mit Nutzen für die Zuhörer.

Das Feedback war einhellig: die besten fünf Minuten der ganzen Veranstaltung.

Für deine nächste Tagung:

1. Hole Leute auf die Bühne, die das Thema schon umsetzen.
2. Prüfe jede Folie: Was macht der Zuhörer morgen anders?
3. Plane Zeit für Fragen aus dem Saal ein.

## 39 · Sa 21.11. · Geschichten aus der Praxis · Szene · Browser

Bild: rp40.jpg · Szene · Browser

Drei Wochen nach unserem Termin war die Landingpage eines Vorstands live. Er selbst hatte mit nächstem Jahr gerechnet.

Wir hatten in kleiner Runde sein wichtigstes Thema durchstrukturiert: Business Story, Zielgruppen, Aufbau des Pitches.

Am Ende schlug ich vor, daraus sofort eine Landingpage zu machen. Seine Sorge: Fragt er sie jetzt an, hat er sie vielleicht nächstes Jahr.

Meine Antwort: So weit, wie wir sind, brauche ich keinen Input mehr. Gib mir das Go, dann ist sie in drei Wochen live.

Er hat das Go gegeben.

Viele Führungskräfte fragen gar nicht mehr nach der richtigen Lösung. Sie haben gelernt, dass sie sie sowieso nicht bekommen.

Der Grund für unser Tempo: Die Story stand, bevor die erste Zeile geschrieben war.

Wenn du etwas schneller willst:

1. Kläre zuerst Story und Zielgruppe, dann das Format.
2. Gib denen freie Hand, die das ganze Bild kennen.
3. Lege den Termin fest, bevor die Arbeit beginnt.

## 40 · So 22.11. · Geschichten aus der Praxis · Satz · Satzkarte

Bild: rp41.jpg · Satz · Satzkarte

Sobald kein Vorstand mehr im Raum ist, reden Führungskräfte mit mir fast immer über dasselbe: eine Führungskraft, die man seit Jahren gewähren lässt.

Probleme, die sie geschaffen hat, bestehen seit Jahren. Und alle wissen es.

Nichts demotiviert die Besten so sehr. Sie halten sich an die Regeln und sehen jeden Tag, dass es für andere keine gibt.

Im selben Gespräch höre ich mit glänzenden Augen von Kleinigkeiten, die plötzlich laufen.

Oder dass endlich jemand da ist, auf den man sich als Ansprechpartner verlassen kann.

Es braucht oft weniger, als man denkt.

Wenn du einen Bereich führst:

1. Frage deine Führungskräfte, welches Problem seit Jahren bekannt ist.
2. Frage, woran es hängt.
3. Entscheide innerhalb eines Monats, was sich ändert.

Wer Fehlverhalten duldet, sagt allen anderen, dass es egal ist.
