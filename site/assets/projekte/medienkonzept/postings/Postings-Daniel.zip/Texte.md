# Postings Daniel Ströbel – LinkedIn (Entwürfe, Stand 12.10.2026)

## 01 · Mi 14.10. · 02 Komplexe Themen · Modell · E Erfolgsmap

Bild: mo5.jpg · Modell · E Erfolgsmap

Dein Thema ist fachlich sauber durchdacht. Und trotzdem kommt es nicht voran.

Das erlebe ich ständig. Und die Reaktion ist fast immer dieselbe: noch eine Analyse, noch eine Berechnung, noch tiefer in die Details.

Damit wirst du nicht erfolgreicher. Fachlich warst du vorher schon gut.

Ein Thema bewegt sich, wenn die Menschen, die du dafür brauchst, es wollen. Und jeder davon hat seinen eigenen Blickwinkel, seine eigenen Ziele und seine eigenen Gründe, Ja oder Nein zu sagen.

Der Vorstand schaut auf etwas anderes als der Vertrieb. Der Nachbarbereich fragt sich, was das für ihn bedeutet. Und irgendwo sitzt jemand, an den keiner gedacht hat und an dem das Thema am Ende hängen bleibt.

Deshalb steht bei mir vor jedem Thema die Erfolgsmap:

• An wem richtest du dich mit deinem Bereich aus? Wessen Erwartungen entscheiden, ob du als erfolgreich wahrgenommen wirst?
• Wen brauchst du, um das Thema durchzubringen?
• Wen hast du bisher zu wenig beachtet?

Und dann für jeden auf der Map: Wie schaut er auf das Thema, was will er erreichen, was treibt ihn an?

Daraus ergibt sich deine Taktik. Mit wem sprichst du zuerst, wen holst du vorher ab, welches Argument zählt bei wem?

Das ist bei jedem Thema anders, weil die Menschen andere sind.

Logik und Fachlichkeit allein haben in einer Organisation noch kein Thema durchgebracht. Das machen die Menschen.

## 02 · Do 15.10. · 01 Strategie im Alltag · Szene · F Foto mit Verlauf und Wort

Bild: rp07.jpg · Szene · F Foto mit Verlauf und Wort

Dein Vorstand gibt kein Zielbild für deinen Bereich vor? Sei froh. Das ist deine Chance.

Damit hast du die Freiheit, deinen Bereich so aufzustellen, dass er erfolgreich sein kann. Genau dafür trägst du als Bereichsleiter die Verantwortung.

Wer jetzt auf Vorgaben von oben wartet, lässt diese Freiheit liegen.

Ein wohlklingender Satz auf einer Folie hilft dabei niemandem. Ein Zielbild beschreibt das Geschäftsmodell deines Bereichs, und zwar so klar, dass jeder deiner Mitarbeiter es erklären kann:

• Für wen arbeiten wir, und welchen Mehrwert liefern wir?
• Woran wird gemessen, ob wir erfolgreich sind?
• Wie müssen wir in Zukunft funktionieren? Die beste Frage dafür: Wie würdest du deinen Bereich heute neu gründen?
• Und was ist mein eigener Beitrag dazu?

Steht das, ergibt sich die Strategie fast von allein. Sie ist die Verbindung zwischen heute und diesem Bild.

Ob ein Bereich ein echtes Zielbild hat, merke ich meist in den ersten Minuten eines Termins. Die Leute leiten ihr Thema aus dem Gesamtbild ab: warum wir heute hier sind, wo es hingehen soll, mit welchem Ergebnis wir rausgehen.

Geht es um Optionen, argumentieren sie sauber und einigen sich nicht am Ende auf einen Kompromiss.

Und sie sind spürbar motivierter, weil alles, woran sie arbeiten, einen Sinn hat.

## 03 · Fr 16.10. · 02 Komplexe Themen · Szene · A Foto pur (Flipchart)

Bild: rp05.jpg · Szene · A Foto pur (Flipchart)

What's in it for me?

Diese Frage stellt sich jeder Vertriebspartner, wenn ein neues Thema auf ihn zukommt. Er stellt sie nicht laut. Aber er entscheidet danach, ob er etwas tut.

Bei Vertriebstagungen und Markteinführungen erlebe ich es immer wieder: tolle Stimmung, viele richtige Fakten, viele bunte Folien.

Wenn ich nachfrage, wie gut die Umsetzung vorbereitet ist, kommt meist kurz ein Schlucken. Und nach vier Wochen spricht keiner mehr von der Tagung.

Deshalb steht diese Frage bei uns am Anfang jeder Vorbereitung. Sie ist das Why, und zwar aus Sicht des Zuhörers: Was bedeutet das für mich? Was bringt mir das?

Erst wenn das klar ist, kommen das How, also wie er grundsätzlich vorgeht, und das What next, der konkrete nächste Schritt.

Die zweite Frage folgt direkt: Wie zeigen wir das so, dass es sofort verstanden wird, ohne große Erklärung? Show, don't tell.

Bevor du die nächste Tagung vorbereitest: Schreib für jede Zielgruppe in einem Satz auf, was sie davon hat.

Wenn dir das schwerfällt, weiß es der Vertrieb hinterher auch nicht.

## 04 · Sa 17.10. · 03 Geschäftsmodell · Weitergedacht

Bild: rp09.jpg · Weitergedacht · Gelbe Satzkarte mit Kreis

Die meisten sehen nur die Grenzen, die heute gesteckt sind.

Das ist kein Vorwurf. Wer einen Bereich führt, denkt in dem Rahmen, den er kennt: Zuständigkeiten, Systeme, Budgets.

Und kaum jemand schlägt eine Lösung vor, die seine eigene Rolle überflüssig machen würde.

Genau deshalb lohnt es sich, die Grenzen ab und zu bewusst wegzudenken.

Mit einem Schadenchef über die Frage, wie sein Schadenmanagement aussähe, wenn er es heute ohne die gewachsenen Abläufe aufbauen würde.

Mit einem Vertriebsdirektor darüber, wie er seinen Vertrieb aufstellen würde, wenn er morgen bei null anfangen dürfte.

Die Antworten sind selten sofort umsetzbar. Aber sie zeigen, welche Grenzen wirklich gesetzt sind und welche nur Gewohnheit.

Eine Voraussetzung gibt es: Der Kern muss laufen. Wer im Alltag noch Löcher stopft, hat für solche Fragen keinen Kopf.

Welche Grenze in deinem Bereich ist eigentlich nur Gewohnheit?

## 05 · So 18.10. · Geschichten aus der Praxis · Satz

Bild: rp10.jpg · Satz · B Anführungszeichen

„Das habe ich noch nicht richtig verstanden. Können Sie mir das mal in Ihren eigenen Worten erklären?“

Diesen Satz habe ich von meinem Vorstand unzählige Male gehört. Meist in Meetings, in denen wichtige Folien gezeigt und wichtige Worte benutzt wurden.

Das Bemerkenswerte: Er hatte es fast immer längst verstanden.

Er wollte wissen, ob derjenige es verstanden hat, der das Thema präsentiert und nachher umsetzen soll.

Denn das Thema muss auch dann richtig weiterlaufen, wenn der Vorstand nicht mehr im Raum ist.

Seine kleine Mikromethode. Ganz ruhig, ohne jede Schärfe. Und jedes Mal hat sie gezeigt, ob ein Thema trägt.

Ich bewundere sie bis heute.

Für beide Seiten des Tisches steckt etwas drin:

• Wer führt, hat eine Frage, die mehr prüft als jeder Statusbericht.
• Wer präsentiert, weiß, worauf es ankommt: das Thema in eigenen Worten erklären können, ohne Folie.

## 06 · Mo 19.10. · Branche eingeordnet · Eingeordnet · B Zahl auf Foto

Bild: rp08.jpg · Eingeordnet · B Zahl auf Foto

77 % sagen: Das Tagesgeschäft verdrängt die strategischen Projekte. Nur 11 % sagen, die Mitarbeitenden verstehen die Strategie.

Die Zahlen stammen aus einer branchenübergreifenden Studie von Wieselhuber. Bei Versicherern erlebe ich es nicht anders.

Was heißt das für einen Bereich? Strategie braucht im Alltag einen festen Platz, sonst gewinnt immer das, was heute brennt.

Zwei Dinge helfen.

Jeder kann in einem Satz sagen, wohin der Bereich will und warum, dann lassen sich Prioritäten im Alltag selbst entscheiden.

Und strategische Themen bekommen feste Termine im Kalender, genauso wie das Tagesgeschäft.

## 07 · Di 20.10. · 01 Strategie im Alltag · Szene · B Foto mit Satz

Bild: rp01.jpg · Szene · B Foto mit Satz

Ich erlebe es immer wieder: Eine neue Strategie soll her, und der erste Schritt ist ein großer Workshop mit dem ganzen Team. Alle sollen mitreden, alle sollen sich wiederfinden.

In der Praxis holst du damit Menschen an den Tisch, die nie gelernt haben, über Strategie zu sprechen, und denen die Erfahrung dafür fehlt.

Heraus kommt ein Kompromiss, auf den sich alle einigen können. Schlechtes Mittelmaß.

Nebenbei entsteht Unsicherheit. Wenn der Chef fragt, wo es hingehen soll, wirkt es, als wüsste der Trainer nicht, wohin die Mannschaft laufen soll.

Die Reihenfolge ist eine andere. Zuerst klärt die Führungskraft, wo der Bereich hinwill und wie er dort erfolgreich ist.

Der Einstieg beginnt dabei nicht mit einem Zweitagesworkshop. Zwei, drei Gespräche mit mir reichen, um den Gesamtzusammenhang klar und stringent zu skizzieren.

Diesen arbeiten wir danach gezielt aus, immer nur in dem zeitlichen Umfang, den es braucht. Zwischen den Terminen arbeite ich weiter und liefere das nächste Level der Ausarbeitung.

Wer oben steht und selbst kein Bild hat, wohin es geht, kann das von seinen Führungskräften auch nicht verlangen.

## 08 · Mi 21.10. · 02 Komplexe Themen · Modell · A Why · How · Next

Bild: rp02.jpg · Modell · A Why · How · Next

„Danke. Bitte bereiten Sie das noch einmal auf.“

Drei Wochen Arbeit. Zwanzig Minuten Vorstand. Ein Satz.

Und du gehst raus und fragst dich, was du falsch gemacht hast.

Ich sage es dir ehrlich: Am Thema lag es nicht. Du hast zu viel gewusst. Und alles erzählt.

Wer sein Thema richtig gut kennt, kann am schlechtesten weglassen. Jedes Detail fühlt sich wichtig an. Ist es auch. Nur nicht für diese eine Entscheidung.

Der Vorstand denkt in dem Moment nicht: schwaches Thema. Er denkt: Was soll ich damit jetzt machen?

Er will drei Dinge wissen. Mehr nicht.

Why?
Was bedeutet das Thema für unser Unternehmen?

How?
Wie gehen wir grundsätzlich vor, um das Ergebnis zu erreichen? Die Details will er erst sehen, wenn er Ja gesagt hat.

What next?
Was muss heute entschieden werden, damit es weitergeht?

Drei Fragen, drei Sätze. Bekommst du die nicht hin, retten dich auch keine vierzig Folien.

## 09 · Do 22.10. · 01 Strategie im Alltag · Szene · B Foto mit Satz (Porträt)

Bild: rp03.jpg · Szene · B Foto mit Satz (Porträt)

Ein ehemaliger Vorstand, mit dem ich bis heute befreundet bin, hat mir das einmal gesagt. Der Satz begleitet mich in fast jedem Projekt.

Ein Vorstand braucht mindestens einen Menschen, der auf Augenhöhe offen mit ihm spricht. Jemanden, der eine andere Meinung fundiert vertritt, ohne Angst, weil er von ihr überzeugt ist.

Und der den nächsten Schritt aufzeigt, weil sich ein Vorstand gar nicht um alle Themen selbst kümmern kann.

Wenn du selbst führst, schreibe dir heute einen Namen auf: Wer sagt dir die Wahrheit?

Fällt dir niemand ein, ist das die wichtigste Aufgabe dieser Woche.

## 10 · Fr 23.10. · 01 Strategie im Alltag · Frage · E Skala

Bild: rp04.jpg · Frage · E Skala

Im Alltag kommt ständig etwas hoch: ein dringender Sachverhalt, eine Vorstandsbeschwerde, ein Termin, der brennt. Das muss heute geregelt werden.

Gleichzeitig steht irgendwo eine Strategie, die erreicht werden soll.

In Bereichen, in denen Strategie wirkt, ist beides sauber getrennt. Dort ist jederzeit klar, womit man sich beschäftigt und womit nicht, damit die Strategie umgesetzt wird.

Ein ehrlicher Test für diese Woche: Gehe deinen Kalender durch und markiere jeden Termin, der direkt auf die Strategie einzahlt. Der Rest ist Tagesgeschäft.

Das Verhältnis zeigt dir, wo du ansetzen musst.

Und wenn dir beim Markieren nicht klar ist, was auf deine Strategie einzahlt, dann ist die Strategie nicht klar genug.

## 11 · Sa 24.10. · 03 Geschäftsmodell · Weitergedacht

Bild: rp11.jpg · Weitergedacht · Gelbe Satzkarte

Diesen Satz habe ich letzte Woche gefühlt zehnmal gehört – von der Anwaltshotline meiner Rechtsschutzversicherung.

Ich hatte ein konkretes Thema und wollte eine Grundeinordnung. Keine abschließende Bewertung, dafür muss man in die Verträge schauen, das ist mir klar. Genau das habe ich gleich zu Beginn gesagt.

Ich wollte eine Denkhilfe für das Gespräch mit meinem Vertragspartner. Eine Richtung.

Bekommen habe ich: Verträge prüfen. Erst mit dem Vertragspartner reden. Wenn das nicht weiterhilft, anwaltlich prüfen lassen.

Keine Einordnung. Keine Richtung. Das Gespräch hätte ich mir sparen können.

Was mich daran ärgert, ist die vergebene Chance. Versicherer können ihre Leistung meistens nur im Schadenfall zeigen. Ein Rechtsschutzversicherer hat mit so einer Hotline etwas, das sich andere wünschen: mehr Kontakte mit dem Kunden, bei denen er ein echtes Problem löst.

Beim Abschluss wird genau dieser Service groß angepriesen. Und in dem Moment, in dem ich ihn brauche, bekomme ich nicht einmal eine Richtung.

Ein Feature, das im entscheidenden Moment nicht hält, was es verspricht, schadet mehr, als wenn es gar nicht da wäre.

Wer Services verantwortet, die beim Abschluss verkauft werden: Wann hat zuletzt jemand geprüft, was davon im Ernstfall beim Kunden ankommt?

## 12 · So 25.10. · 01 Strategie im Alltag · Aufgegriffen

Bild: rp12.jpg · Aufgegriffen · Zitatkarte

„Gute Beratung führt nicht möglichst schnell zu einer Lösung. Gute Beratung führt Schritt für Schritt zu einer begründeten Entscheidung.“

Das schreibt Matthias Weber, Vertriebsvorstand bei HDI Bancassurance, diese Woche in seiner Kolumne. Den Satz unterschreibe ich sofort.

Sein Punkt: Die Regulierung setzt den Rahmen. Den Unterschied macht die Umsetzung.

Wie es aussieht, wenn das keiner tut, habe ich gestern erzählt. Anwaltshotline, konkrete Frage, und als Antwort immer wieder „Das kommt darauf an“. Formal alles richtig. Weitergekommen bin ich keinen Schritt.

Dasselbe erlebe ich in Häusern nach innen: Die Regel wird zur Begründung, warum etwas nicht geht.

Wer Vertrieb oder Service führt, kann seinen Leuten hier viel abnehmen. Sag ihnen genau, wo die Grenze verläuft. Und was sie bis dahin klar sagen dürfen, ohne sich abzusichern.

Wer das weiß, traut sich, eine Richtung zu geben.

## 13 · Mo 26.10. · 03 Geschäftsmodell · Frage · C Fragezeichen

Bild: rp13.jpg · Frage · C Fragezeichen

Wenn ich mit einer Führungskraft über die Zukunft ihres Bereichs spreche, frage ich ziemlich früh:

„Wie würdest du deinen Bereich aufbauen, wenn du ihn heute neu gründen würdest?“

Erst danach reden wir über Strategie. Solange keiner weiß, wo es hingehen soll, gibt es keine Chance auf eine gescheite Strategie. Ist das Bild klar, ergibt sie sich fast von allein. Sie ist dann der Weg von heute dorthin.

Vieles in einem Bereich halten wir für gegeben, nur weil es schon immer so war: Zuständigkeiten, Abläufe, Schnittstellen. Wer neu gründet, darf all das infrage stellen.

Damit daraus keine Wunschliste wird, gehe ich drei Fragen durch:

• Welches Problem hat dein Kunde wirklich?
• Wie löst du es?
• Und ist er überhaupt bereit, es zu lösen?

Ein Rat aus vielen dieser Gespräche: Beantworte die Frage zuerst allein. Stellst du sie gleich dem ganzen Team, entsteht Unsicherheit. Viele denken dann zuerst an ihren eigenen Platz – und in dieser Lage denkt keiner frei.

## 14 · Di 27.10. · 01 Strategie im Alltag · Szene · A Foto mit Satz

Bild: rp14.jpg · Szene · A Foto mit Satz

Logik, Regelungen, saubere Absprachen – allein verändern sie im Alltag wenig.

Das habe ich verstanden, als ich selbst Führungsverantwortung bei einem Versicherer hatte.

Menschen sind im Alltag viel ausgeprägter, als es jedes Persönlichkeitsmodell beschreibt. Und unter Führungskräften laufen Strömungen, die in keinem Organigramm stehen: wer welche Interessen verteidigt und wer worauf Einfluss hat.

An vielen Stellen hast du mit reiner Logik fast keine Chance, etwas zu bewegen.

Was wirkt, ist Führung im Alltag. Kein Mikromanagement. Aber so aufgestellt sein, dass die Leute merken: Da ist jemand, der Richtung gibt, nachhält und entscheidet.

Bevor du die nächste Regel aufschreibst, frag dich deshalb zwei Dinge:

• Wer muss sich dafür im Alltag anders verhalten?
• Und woran merkt er, dass es dir ernst ist?
