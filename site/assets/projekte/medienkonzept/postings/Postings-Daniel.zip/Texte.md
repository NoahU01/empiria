# Postings Daniel Ströbel – LinkedIn (Entwürfe, Stand 12.10.2026)

## 01 · Di 20.10. · Durchsetzung · Werkzeug

Bild: p1.jpg · Foto aus der Arbeit · Einzelbild 4:5

Bevor ich mit einem Kunden an einer Vorstandsvorlage arbeite, schauen wir uns keine einzige Folie an.

Wir beantworten drei Fragen, und meistens verändert das die Unterlage mehr als jede Überarbeitung.

Wen brauche ich, damit das Thema durchgeht? Das sind fast immer mehr Menschen als die, die am Ende im Raum sitzen: der Vorstand, aber auch der Kollege, dessen Bereich betroffen ist, und die Referentin, die die Vorlage vorab liest.

Wen habe ich bislang zu wenig berücksichtigt? Hier steckt oft der Grund, warum gute Themen in der Sitzung hängen bleiben. Einer fühlt sich übergangen und stellt die Frage, auf die niemand vorbereitet ist.

An wem richte ich das Thema eigentlich aus? Wer das klar beantwortet, weiß auch, mit wem er vorher sprechen muss und in welcher Reihenfolge.

Die Folie kommt danach, und sie wird kürzer.

Wenn du nächste Woche eine Entscheidung brauchst: Nimm dir heute zehn Minuten, beantworte die drei Fragen auf einem Blatt und plane die zwei Gespräche, die vor der Sitzung stattfinden müssen.

## 02 · Mi 21.10. · Richtung · Beobachtung

Bild: p2.jpg · Foto aus der Arbeit · Einzelbild 4:5

In meinen Gesprächen mit Führungskräften bei Versicherern hat noch nie jemand gesagt, er habe keine Strategie.

Was ich höre, ist etwas anderes: dass im Alltag zu wenig davon ankommt. Die Strategie steht auf der Folie, die Begriffe kennt jeder, und trotzdem entscheiden die Leute im Bereich am Montag genauso wie vor einem Jahr.

Das hat einen einfachen Grund. Aus vier Feldern mit Schlagworten kann niemand ableiten, was er diese Woche anders machen soll. Es fehlt das Bild, wie der Bereich in Zukunft funktioniert, und es fehlt die Entscheidung, was man dafür bewusst nicht mehr macht.

Ein Test, den du heute machen kannst: Frag drei deiner Führungskräfte, was sie wegen der Strategie in dieser Woche anders entscheiden. Wenn die Antworten weit auseinanderliegen oder lange auf sich warten lassen, weißt du, wo du ansetzen musst.

Ansetzen heißt dann: die vorhandene Strategie so schärfen, dass jeder sie in einem Satz für seinen Bereich übersetzen kann, einschließlich der Dinge, die wegfallen.

## 03 · Do 22.10. · Umsetzungspower · Geschichte

Bild: p3.jpg · Zitat mit Porträt · Einzelbild 4:5

Ein befreundeter Vorstand hat einem Kollegen einmal beschrieben, wie ich arbeite:

„Er stellt Fragen, zeichnet, dreht das iPad um und sagt: Eigentlich ist es doch so.“

Der Satz trifft ziemlich genau, was in fast jedem meiner Projekte passiert. Komplexe Themen werden in Besprechungen meist mit immer mehr Folien beantwortet. Ich versuche, sie auf eine Skizze zu bringen: wer mit wem zusammenhängt, wo eine Entscheidung entsteht und wo sie stockt.

Sobald das Bild auf dem Tisch liegt, ändert sich das Gespräch. Die Leute diskutieren nicht mehr über Formulierungen. Sie zeigen auf eine Stelle und sagen: Genau da hakt es.

Probier es beim nächsten verfahrenen Termin aus. Nimm ein Blatt, zeichne die drei, vier Beteiligten und die Pfeile dazwischen und dreh das Blatt zu deinem Gegenüber. Du wirst merken, wie schnell aus einer Diskussion ein gemeinsames Bild wird.

## 04 · Mo 26.10. · Zukunft · Werkzeug

Bild: p4.jpg · Foto aus der Arbeit · Einzelbild 4:5

Wie würdest du deinen Bereich aufbauen, wenn du ihn heute neu gründen würdest?

Die Frage stelle ich in Strategieterminen oft, und sie bringt das Gespräch schnell an die Stellen, über die sonst keiner spricht. Damit sie trägt, brauchst du drei Unterfragen.

Würdest du die Aufgaben noch genauso zuschneiden? Viele Zuständigkeiten sind historisch gewachsen und heute vor allem Schnittstellen.

Würdest du dich an derselben Stelle der Wertschöpfung positionieren? Manches, was der Bereich selbst macht, könnte ein Partner besser, und an anderer Stelle fehlt etwas, das heute niemand verantwortet.

Würdest du dieselben Zielgruppen und Stakeholder bedienen? Oft zeigt sich hier, dass der Bereich auf die Erwartungen von gestern eingestellt ist.

Eine Einschränkung gehört dazu. Die Frage funktioniert erst, wenn dein Kern im Griff ist: wenn du dein heutiges Geschäftsmodell erklären kannst und weißt, wen du für Veränderungen brauchst. Vorher entsteht eine Wunschliste.

Wenn dein Vorstand von dir erwartet, über den Tellerrand zu denken, fang mit diesen drei Fragen an und schreib zu jeder einen Satz auf, bevor du über Maßnahmen sprichst.

## 05 · Di 27.10. · Umsetzungspower · Denkfehler

Bild: p5.jpg · Grafik · Einzelbild 4:5

Ein Thema ist besprochen, alle nicken, der Termin endet gut. Zwei Wochen später liegt es wieder bei dir, genauso offen wie vorher.

Das passiert in vielen Häusern. Meist ist am Ende des Termins offen geblieben, wer das Thema jetzt treibt und in welcher Form es zurückkommt.

Ich schließe deshalb jede Abstimmung mit drei Punkten ab. Wer übernimmt das Thema ab jetzt? Bis wann kommt es zurück? Und in welcher Form: als Entscheidungsvorlage mit Empfehlung, damit beim nächsten Termin eine Entscheidung fällt.

Das kostet zwei Minuten am Ende des Termins. Danach kannst du das Thema guten Gewissens loslassen, weil klar ist, dass es beim nächsten Mal eine Stufe weiter ist.

So arbeite ich auch mit meinen Kunden: Sie geben mir ein Thema, und ab da liegt es bei mir, bis es entscheidungsreif auf ihrem Tisch liegt.

## 06 · Mi 28.10. · Durchsetzung · Wissen hergeben

Bild: d1.jpg · Dokument · 6 Seiten (PDF)

Ein wichtiges Thema hat selten nur ein Publikum. Vorstand, Aufsichtsrat, Vertrieb und dein Team schauen mit unterschiedlichen Fragen darauf, und jede davon braucht eine eigene Antwort.

Der Vorstand will wissen, welche Entscheidung du von ihm brauchst und welches Risiko er damit eingeht.

Der Aufsichtsrat will sehen, dass das Thema zur Strategie passt und steuerbar bleibt.

Der Vertrieb will wissen, was er davon hat und wie er es seinem Kunden in einem Satz erklärt.

Dein Team will wissen, was sich ab Montag für jeden Einzelnen ändert.

Im Dokument findest du für alle vier die Leitfrage, die typischen Einwände und einen Satz, mit dem du das Gespräch eröffnest. Leg es neben deine nächste Vorlage und prüf, ob du alle vier Fragen beantwortet hast.

Der Gedanke dahinter begleitet mich in jedem Projekt: Menschen überzeugst du, indem du dein Gegenüber erfolgreich machst.
