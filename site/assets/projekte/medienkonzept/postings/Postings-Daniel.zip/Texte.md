# Postings Daniel Ströbel – LinkedIn (Entwürfe, Stand 12.10.2026)

## 01 · Mi 14.10. · 02 Komplexe Themen · Modell · E Erfolgsmap

Bild: mo5.jpg · Modell · E Erfolgsmap

Dein Thema ist fachlich sauber durchdacht. Und trotzdem kommt es nicht voran.

Das erlebe ich ständig. Und die Reaktion ist fast immer dieselbe: noch eine Analyse, noch eine Berechnung, noch tiefer in die Details.

Damit wirst du nicht erfolgreicher. Fachlich warst du vorher schon gut.

Ein Thema bewegt sich, wenn die Menschen, die du dafür brauchst, es wollen. Und jeder davon hat seinen eigenen Blickwinkel, seine eigenen Ziele und seine eigenen Gründe, Ja oder Nein zu sagen.

Der Vorstand schaut auf etwas anderes als der Vertrieb. Der Nachbarbereich fragt sich, was das für ihn bedeutet. Und irgendwo sitzt jemand, an den keiner gedacht hat und an dem das Thema am Ende hängen bleibt.

Deshalb steht bei mir vor jedem Thema die Erfolgsmap:

• An wem richtest du dich mit deinem Bereich aus? Wessen Erwartungen entscheiden, ob du als erfolgreich wahrgenommen wirst?
• Wen brauchst du, um das Thema durchzubringen?
• Wen hast du bisher zu wenig beachtet?

Und dann für jeden auf der Map: Wie schaut er auf das Thema, was will er erreichen, was treibt ihn an?

Daraus ergibt sich deine Taktik. Mit wem sprichst du zuerst, wen holst du vorher ab, welches Argument zählt bei wem?

Das ist bei jedem Thema anders, weil die Menschen andere sind.

Logik und Fachlichkeit allein haben in einer Organisation noch kein Thema durchgebracht. Das machen die Menschen.

## 02 · Do 15.10. · 01 Strategie im Alltag · Szene · F Foto mit Verlauf und Wort

Bild: rp07.jpg · Szene · F Foto mit Verlauf und Wort

Dein Vorstand gibt kein Zielbild für deinen Bereich vor? Sei froh. Das ist deine Chance.

Damit hast du die Freiheit, deinen Bereich so aufzustellen, dass er erfolgreich sein kann. Genau dafür trägst du als Bereichsleiter die Verantwortung.

Wer jetzt auf Vorgaben von oben wartet, lässt diese Freiheit liegen.

Ein wohlklingender Satz auf einer Folie hilft dabei niemandem. Ein Zielbild beschreibt das Geschäftsmodell deines Bereichs, und zwar so klar, dass jeder deiner Mitarbeiter es erklären kann:

• Für wen arbeiten wir, und welchen Mehrwert liefern wir?
• Woran wird gemessen, ob wir erfolgreich sind?
• Wie müssen wir in Zukunft funktionieren? Die beste Frage dafür: Wie würdest du deinen Bereich heute neu gründen?
• Und was ist mein eigener Beitrag dazu?

Steht das, ergibt sich die Strategie fast von allein. Sie ist die Verbindung zwischen heute und diesem Bild.

Ob ein Bereich ein echtes Zielbild hat, merke ich meist in den ersten Minuten eines Termins. Die Leute leiten ihr Thema aus dem Gesamtbild ab: warum wir heute hier sind, wo es hingehen soll, mit welchem Ergebnis wir rausgehen.

Geht es um Optionen, argumentieren sie sauber und einigen sich nicht am Ende auf einen Kompromiss.

Und sie sind spürbar motivierter, weil alles, woran sie arbeiten, einen Sinn hat.

## 03 · Fr 16.10. · 02 Komplexe Themen · Szene · A Foto pur (Flipchart)

Bild: rp05.jpg · Szene · A Foto pur (Flipchart)

What's in it for me?

Diese Frage stellt sich jeder Vertriebspartner, wenn ein neues Thema auf ihn zukommt. Er stellt sie nicht laut. Aber er entscheidet danach, ob er etwas tut.

Bei Vertriebstagungen und Markteinführungen erlebe ich es immer wieder: tolle Stimmung, viele richtige Fakten, viele bunte Folien.

Wenn ich nachfrage, wie gut die Umsetzung vorbereitet ist, kommt meist kurz ein Schlucken. Und nach vier Wochen spricht keiner mehr von der Tagung.

Deshalb steht diese Frage bei uns am Anfang jeder Vorbereitung. Sie ist das Why, und zwar aus Sicht des Zuhörers: Was bedeutet das für mich? Was bringt mir das?

Erst wenn das klar ist, kommen das How, also wie er grundsätzlich vorgeht, und das What next, der konkrete nächste Schritt.

Die zweite Frage folgt direkt: Wie zeigen wir das so, dass es sofort verstanden wird, ohne große Erklärung? Show, don't tell.

Bevor du die nächste Tagung vorbereitest: Schreib für jede Zielgruppe in einem Satz auf, was sie davon hat.

Wenn dir das schwerfällt, weiß es der Vertrieb hinterher auch nicht.

## 04 · Sa 17.10. · 03 Geschäftsmodell · Weitergedacht

Bild: rp09.jpg · Weitergedacht · Gelbe Satzkarte mit Kreis

Die meisten sehen nur die Grenzen, die heute gesteckt sind.

Das ist kein Vorwurf. Wer einen Bereich führt, denkt in dem Rahmen, den er kennt: Zuständigkeiten, Systeme, Budgets.

Und kaum jemand schlägt eine Lösung vor, die seine eigene Rolle überflüssig machen würde.

Genau deshalb lohnt es sich, die Grenzen ab und zu bewusst wegzudenken.

Mit einem Schadenchef über die Frage, wie sein Schadenmanagement aussähe, wenn er es heute ohne die gewachsenen Abläufe aufbauen würde.

Mit einem Vertriebsdirektor darüber, wie er seinen Vertrieb aufstellen würde, wenn er morgen bei null anfangen dürfte.

Die Antworten sind selten sofort umsetzbar. Aber sie zeigen, welche Grenzen wirklich gesetzt sind und welche nur Gewohnheit.

Eine Voraussetzung gibt es: Der Kern muss laufen. Wer im Alltag noch Löcher stopft, hat für solche Fragen keinen Kopf.

Welche Grenze in deinem Bereich ist eigentlich nur Gewohnheit?

## 05 · So 18.10. · Geschichten aus der Praxis · Satz

Bild: rp10.jpg · Satz · B Anführungszeichen

„Das habe ich noch nicht richtig verstanden. Können Sie mir das mal in Ihren eigenen Worten erklären?“

Diesen Satz habe ich von meinem Vorstand unzählige Male gehört. Meist in Meetings, in denen wichtige Folien gezeigt und wichtige Worte benutzt wurden.

Das Bemerkenswerte: Er hatte es fast immer längst verstanden.

Er wollte wissen, ob derjenige es verstanden hat, der das Thema präsentiert und nachher umsetzen soll.

Denn das Thema muss auch dann richtig weiterlaufen, wenn der Vorstand nicht mehr im Raum ist.

Seine kleine Mikromethode. Ganz ruhig, ohne jede Schärfe. Und jedes Mal hat sie gezeigt, ob ein Thema trägt.

Ich bewundere sie bis heute.

Für beide Seiten des Tisches steckt etwas drin:

• Wer führt, hat eine Frage, die mehr prüft als jeder Statusbericht.
• Wer präsentiert, weiß, worauf es ankommt: das Thema in eigenen Worten erklären können, ohne Folie.

## 06 · Mo 19.10. · Branche eingeordnet · Eingeordnet · B Zahl auf Foto

Bild: rp08.jpg · Eingeordnet · B Zahl auf Foto

77 % sagen: Das Tagesgeschäft verdrängt die strategischen Projekte. Nur 11 % sagen, die Mitarbeitenden verstehen die Strategie.

Die Zahlen stammen aus einer branchenübergreifenden Studie von Wieselhuber. Bei Versicherern erlebe ich es nicht anders.

Was heißt das für einen Bereich? Strategie braucht im Alltag einen festen Platz, sonst gewinnt immer das, was heute brennt.

Zwei Dinge helfen.

Jeder kann in einem Satz sagen, wohin der Bereich will und warum, dann lassen sich Prioritäten im Alltag selbst entscheiden.

Und strategische Themen bekommen feste Termine im Kalender, genauso wie das Tagesgeschäft.

## 07 · Di 20.10. · 01 Strategie im Alltag · Szene · B Foto mit Satz

Bild: rp01.jpg · Szene · B Foto mit Satz

Ich erlebe es immer wieder: Eine neue Strategie soll her, und der erste Schritt ist ein großer Workshop mit dem ganzen Team. Alle sollen mitreden, alle sollen sich wiederfinden.

In der Praxis holst du damit Menschen an den Tisch, die nie gelernt haben, über Strategie zu sprechen, und denen die Erfahrung dafür fehlt.

Heraus kommt ein Kompromiss, auf den sich alle einigen können. Schlechtes Mittelmaß.

Nebenbei entsteht Unsicherheit. Wenn der Chef fragt, wo es hingehen soll, wirkt es, als wüsste der Trainer nicht, wohin die Mannschaft laufen soll.

Die Reihenfolge ist eine andere. Zuerst klärt die Führungskraft, wo der Bereich hinwill und wie er dort erfolgreich ist.

Der Einstieg beginnt dabei nicht mit einem Zweitagesworkshop. Zwei, drei Gespräche mit mir reichen, um den Gesamtzusammenhang klar und stringent zu skizzieren.

Diesen arbeiten wir danach gezielt aus, immer nur in dem zeitlichen Umfang, den es braucht. Zwischen den Terminen arbeite ich weiter und liefere das nächste Level der Ausarbeitung.

Wer oben steht und selbst kein Bild hat, wohin es geht, kann das von seinen Führungskräften auch nicht verlangen.

## 08 · Mi 21.10. · 02 Komplexe Themen · Modell · A Why · How · Next

Bild: rp02.jpg · Modell · A Why · How · Next

„Danke. Bitte bereiten Sie das noch einmal auf.“

Drei Wochen Arbeit. Zwanzig Minuten Vorstand. Ein Satz.

Und du gehst raus und fragst dich, was du falsch gemacht hast.

Ich sage es dir ehrlich: Am Thema lag es nicht. Du hast zu viel gewusst. Und alles erzählt.

Wer sein Thema richtig gut kennt, kann am schlechtesten weglassen. Jedes Detail fühlt sich wichtig an. Ist es auch. Nur nicht für diese eine Entscheidung.

Der Vorstand denkt in dem Moment nicht: schwaches Thema. Er denkt: Was soll ich damit jetzt machen?

Er will drei Dinge wissen. Mehr nicht.

Why?
Was bedeutet das Thema für unser Unternehmen?

How?
Wie gehen wir grundsätzlich vor, um das Ergebnis zu erreichen? Die Details will er erst sehen, wenn er Ja gesagt hat.

What next?
Was muss heute entschieden werden, damit es weitergeht?

Drei Fragen, drei Sätze. Bekommst du die nicht hin, retten dich auch keine vierzig Folien.

## 09 · Do 22.10. · 01 Strategie im Alltag · Szene · B Foto mit Satz (Porträt)

Bild: rp03.jpg · Szene · B Foto mit Satz (Porträt)

Du stellst in der Runde eine Idee vor. Alle nicken. Du fragst: „Sieht das jemand anders?“ Stille.

Je höher du kommst, desto seltener sagt dir jemand ins Gesicht, was er denkt.

Mit Budget und Karriere hat das nur am Rande zu tun. Ab einer gewissen Stufe ist da Ehrfurcht.

Viele glauben, einem Vorstand oder einem Hauptabteilungsleiter dürfe man gar nicht die Wahrheit sagen. Und sie sind schlicht unsicher.

Was dir dann fehlt, ist ein Mensch auf Augenhöhe. Jemand, der
• eine andere Perspektive einnimmt und sie gut begründen kann.
• gezielte Fragen stellt, die dich wirklich zum Nachdenken bringen und dir einen anderen Blick auf die Dinge geben.
• Gesamtzusammenhänge aufzeigt und den nächsten Schritt klar benennt.

Schreibe dir heute einen Namen auf:
Wer sagt dir die Wahrheit? Ungeschönt, ohne Rücksicht auf deine Position.

Fällt dir niemand ein, ist das die wichtigste Aufgabe dieser Woche.

## 10 · Fr 23.10. · 01 Strategie im Alltag · Frage · E Skala

Bild: rp04.jpg · Frage · E Skala

Im Alltag kommt ständig etwas hoch: ein dringender Sachverhalt, eine Vorstandsbeschwerde, ein Termin, der brennt. Das muss heute geregelt werden.

Gleichzeitig steht irgendwo eine Strategie, die erreicht werden soll.

In Bereichen, in denen Strategie wirkt, ist beides sauber getrennt. Dort ist jederzeit klar, womit man sich beschäftigt und womit nicht, damit die Strategie umgesetzt wird.

Ein ehrlicher Test für diese Woche: Gehe deinen Kalender durch und markiere jeden Termin, der direkt auf die Strategie einzahlt. Der Rest ist Tagesgeschäft.

Das Verhältnis zeigt dir, wo du ansetzen musst.

Und wenn dir beim Markieren nicht klar ist, was auf deine Strategie einzahlt, dann ist die Strategie nicht klar genug.

## 11 · Sa 24.10. · 03 Geschäftsmodell · Weitergedacht

Bild: rp11.jpg · Weitergedacht · Gelbe Satzkarte

Diesen Satz habe ich letzte Woche gefühlt zehnmal gehört – von der Anwaltshotline meiner Rechtsschutzversicherung.

Ich hatte ein konkretes Thema und wollte eine Grundeinordnung. Keine abschließende Bewertung, dafür muss man in die Verträge schauen, das ist mir klar. Genau das habe ich gleich zu Beginn gesagt.

Ich wollte eine Denkhilfe für das Gespräch mit meinem Vertragspartner. Eine Richtung.

Bekommen habe ich: Verträge prüfen. Erst mit dem Vertragspartner reden. Wenn das nicht weiterhilft, anwaltlich prüfen lassen.

Keine Einordnung. Keine Richtung. Das Gespräch hätte ich mir sparen können.

Was mich daran ärgert, ist die vergebene Chance. Versicherer können ihre Leistung meistens nur im Schadenfall zeigen. Ein Rechtsschutzversicherer hat mit so einer Hotline etwas, das sich andere wünschen: mehr Kontakte mit dem Kunden, bei denen er ein echtes Problem löst.

Beim Abschluss wird genau dieser Service groß angepriesen. Und in dem Moment, in dem ich ihn brauche, bekomme ich nicht einmal eine Richtung.

Ein Feature, das im entscheidenden Moment nicht hält, was es verspricht, schadet mehr, als wenn es gar nicht da wäre.

Wer Services verantwortet, die beim Abschluss verkauft werden: Wann hat zuletzt jemand geprüft, was davon im Ernstfall beim Kunden ankommt?

## 12 · So 25.10. · 01 Strategie im Alltag · Aufgegriffen · Foto mit Satz

Bild: rp12.jpg · Aufgegriffen · Foto mit Satz

„Gute Beratung führt nicht möglichst schnell zu einer Lösung. Gute Beratung führt Schritt für Schritt zu einer begründeten Entscheidung.“

Das hat Matthias Weber, Vertriebsvorstand bei HDI Bancassurance, in seiner Montagskolumne geschrieben. Den Satz unterschreibe ich sofort.

Sein Punkt: Die Regulierung setzt den Rahmen. Den Unterschied macht, wie wir ihn mit Leben füllen.

Wie es aussieht, wenn das keiner tut, habe ich gestern erzählt. Anwaltshotline, konkrete Frage, und als Antwort immer wieder „Das kommt darauf an“. Formal alles richtig. Weitergekommen bin ich keinen Schritt.

Und genau das erlebe ich in den Häusern auch nach innen. Die Regel wird zur Begründung, warum etwas nicht geht. Keiner traut sich, eine Richtung zu geben, weil er Angst hat, sich festzulegen.

Wenn du Vertrieb oder Service führst, kannst du deinen Leuten genau hier richtig viel abnehmen.

Sie müssen wissen, wo die Grenze verläuft. Und was sie bis dahin klar sagen dürfen, ohne sich dreimal abzusichern.

Wer das weiß, gibt dem Kunden eine Richtung. Und genau dafür ruft er an.

## 13 · Mo 26.10. · 03 Geschäftsmodell · Frage · C Fragezeichen

Bild: rp13.jpg · Frage · C Fragezeichen

Diese Frage stelle ich ziemlich früh, wenn es um die Zukunft eines Bereichs geht. Und die Antwort sieht jedes Mal anders aus als das, was heute da ist.

Zuständigkeiten, Abläufe, Schnittstellen: Vieles ist einfach so gewachsen. Also baut man weiter auf dem, was da ist. Wer neu gründet, darf all das infrage stellen.

Erst wenn das Bild steht, reden wir über Strategie. Ohne dieses Bild gibt es keine gescheite Strategie. Mit ihm ergibt sie sich fast von allein. Sie ist dann der Weg von heute dorthin.

Damit aus der Frage keine Wunschliste wird, gehe ich drei Dinge durch:

• Welches Problem hat dein Kunde wirklich?
• Wie löst du es?
• Und ist er überhaupt bereit, es zu lösen?

Einen Rat gebe ich dabei jedes Mal mit: Beantworte die Frage zuerst allein.

Stellst du sie gleich deinem ganzen Team, fragt sich jeder zuerst, ob es seinen Job danach noch gibt. Und mit dieser Sorge im Kopf denkt keiner frei.

## 14 · Di 27.10. · 01 Strategie im Alltag · Szene · A Foto mit Satz

Bild: rp14.jpg · Szene · A Foto mit Satz

Als ich selbst eine Abteilung geführt habe, rund 40 Leute an zwei Standorten, habe ich eine Sache gründlich unterschätzt.

Ich dachte: Wenn die Logik stimmt, läuft der Rest. Saubere Prozesse, klare Regelungen, ordentliche Absprachen.

Das hat nicht gereicht. Nicht annähernd.

Menschen sind im Alltag viel ausgeprägter, als es jedes Persönlichkeitsmodell beschreibt. Und unter Führungskräften laufen Strömungen, die in keinem Organigramm stehen: wer welche Interessen verteidigt und wer worauf Einfluss hat.

An vielen Stellen hast du mit reiner Logik fast keine Chance.

Was wirkt, ist Führung im Alltag. Kein Mikromanagement. Aber so aufgestellt sein, dass deine Leute merken: Da ist jemand, der Richtung gibt, nachhält und entscheidet.

Bevor du die nächste Regel aufschreibst, stelle dir zwei Fragen:

• Wer muss sich dafür im Alltag anders verhalten?
• Und woran merkt er, dass es dir ernst ist?

## 15 · Mi 28.10. · 02 Führung · Modell · D Drei Kreise

Bild: rp15.jpg · Modell · D Drei Kreise

Jemand ist fachlich richtig gut. Also wird er befördert. Und dann gibt man ihm zwölf bis vierundzwanzig Monate, um in die Rolle hineinzuwachsen.

Das ist der größte Fehler, den ich bei dem Thema sehe.

In diesen Monaten ist er gar nicht in der Lage, seinen Job zu machen. Mit ihm hat nie jemand richtig darüber gesprochen, was von ihm erwartet wird. Also läuft er jeden Tag im Alarmmodus: Regeltermine, brennende Themen, Stellen nicht besetzt, Löcher stopfen.

Und nach einem Jahr heißt es: „Von dieser Person hätten wir uns mehr erwartet.“

Das finde ich ganz schlimm. Am Können liegt es dabei fast nie. Ihm fehlt das System, mit dem er das Spiel überhaupt gewinnen kann.

Vor dem ersten Tag muss klar sein, was die Rolle verlangt. In klaren Worten. Drei Dinge gehören dazu:

• Fachexpertise. Die bringt er mit. Zur Führungskraft macht sie ihn allein noch nicht.

• Führung. Wie nehme ich mein Team mit?

• Geschäftsmodell. Verstehe ich, wie wir erfolgreich sind, und trage ich aktiv dazu bei?

Wenn du demnächst jemanden beförderst: Sprich das mit ihm durch, bevor er anfängt. Nicht nach einem Jahr.

## 16 · Do 29.10. · Geschichten aus der Praxis · Du als Person · Foto

Bild: rp16.jpg · Du als Person · Foto

Im Sommer 2025 stand ich wieder vor dem Lloyd's Building. 25 Jahre, nachdem ich in London in der Rückversicherung gearbeitet habe.

Ich kam damals von einem ganz normalen Versicherer aus Stuttgart. Wenig Zugang zu neuen Themen, Schulungen weit weg, das Budget dafür knapp.

In London saßen alle Firmen, die mit Versicherung und Rückversicherung zu tun haben, im selben Viertel nahe dem Tower. Und sie haben gemeinsam dafür gesorgt, dass dieser Marktplatz funktioniert.

Kam ein neues Thema hoch, rechtlich oder fachlich, hat sich sofort eine Firma darum gekümmert. Aufbereitet, kurze Einleitung, kurzer Impuls nach Feierabend. Danach Essen und Trinken.

Man konnte sich praktisch jeden Tag weiterbilden und Leute aus anderen Häusern treffen. Über die Grenzen der eigenen Firma hinaus.

Für die damalige Zeit war das bemerkenswert.

Jahre später, zurück bei meinem früheren Arbeitgeber, suchte das Führungsteam nach Ideen, die man im Haus entwickeln könnte. Wir haben genau das eingebracht: „90 Minuten Wissen to go“.

Das Format gibt es dort bis heute. Und es wird richtig gut angenommen.

## 17 · Fr 30.10. · Werkstatt · Werkstatt · Foto

Bild: rp17.jpg · Werkstatt · Foto

Im letzten Jahr habe ich mir ein Thema komplett selbst beigebracht: KI.

Ich wollte verstehen, wie die Systeme zusammenarbeiten, wie man Agenten baut und wie man Abläufe automatisiert. Also habe ich angefangen zu bauen.

Da bleiben Nerven auf der Strecke. Und manchmal fragst du dich, was das alles soll.

Trotzdem ist es eine super Geschichte, sich da hineinzufuchsen. Du lernst es wirklich beim Tun, weil du ständig fragen kannst: Wie funktioniert das jetzt? Was ist der nächste Schritt?

Gestolpert bin ich dabei fast immer an derselben Stelle: wenn ich zu viel vorgegeben und zu wenig gefragt habe.

Was mir seitdem auffällt: Über KI wird in vielen Häusern lebhaft diskutiert. Oft von Leuten, die sie selbst noch nicht einmal im Kleinen eingesetzt haben. Da draußen gibt es viel Meinung und wenig Erfahrungswissen.

Wenn du in deinem Haus über KI mitentscheidest: Probiere sie vorher selbst aus. An einem echten Thema aus deinem Alltag.

Erst dann weißt du, worüber du eigentlich entscheidest.

## 18 · Sa 31.10. · 03 Geschäftsmodell · Weitergedacht · Foto

Bild: rp18.jpg · Weitergedacht · Foto

2017 hatten wir ein Problem, das viele kleine Unternehmen kennen.

Wir saßen in Stuttgart, umringt von großen Autobauern, Unternehmensberatungen, Wirtschaftsprüfern, Versicherern und Banken. Gute Praktikanten und Werkstudenten zu finden, war für uns strukturell schwer. Eine Ausschreibung allein bringt dich da nicht ans Ziel.

Also haben wir uns gefragt: Wenn sie nicht zu uns kommen, wie kommen wir zu ihnen?

Über einen Bekannten kam der Kontakt zur Macromedia. Die Hochschule suchte Dozenten aus der Praxis. Angeboten hatte ich einen Gastvortrag. Am Ende habe ich die Vorlesung übernommen. Montags um 8 Uhr, auf Englisch. Für einen Nachtmenschen wie mich eine echte Herausforderung.

Das Fach habe ich bewusst gewählt: Projektmanagement. Kostenrechnung hätte ich auch gekonnt. Aber nur bei Projektmanagement konnte ich die Leute, die sich hervortun, später auch brauchen.

Zwei Studenten haben mich direkt gechallenged. Kurz darauf waren sie unsere Werkstudenten, dann Praktikanten. Mit einem von ihnen bin ich heute noch befreundet.

Die Frage dahinter stelle ich mir seitdem immer wieder: Wo habe ich einen strukturellen Nachteil? Und wie mache ich daraus einen Vorteil, den andere nicht haben?

## 19 · So 01.11. · 03 Geschäftsmodell · Aufgegriffen · Zitatkarte

Bild: rp19.jpg · Aufgegriffen · Zitatkarte

Vor der DKM hat Tobias Knörrer, Geschäftsführer der bbg und damit Veranstalter der Messe, im Interview mit VWheute etwas gesagt, das ich gerne weiterdrehe.

Bei KI stelle die Branche oft die falsche Frage, nämlich wie der Makler KI einsetzt. Die richtige Frage sei, welche Leistungen Kunden in zehn Jahren überhaupt noch brauchen.

Seine Antwort für Makler finde ich stark: Was bleibt, ist das Urteil bei unvollständiger Information, die Fähigkeit, einen Kunden zu einer Entscheidung zu bewegen, und die Haftung für das Ergebnis.

Da bin ich voll bei ihm. Und die Frage gilt genauso in jedem Versicherer. Für jeden einzelnen Bereich.

• Welche Leistungen deines Bereichs braucht dein Unternehmen in zehn Jahren noch?
• Welche davon braucht euer Kunde wirklich?
• Und welche gibt es nur, weil es sie schon immer gab?

Wer so fragt, ist ziemlich schnell bei der Frage, wie er seinen Bereich heute neu gründen würde.

KI hilft dir dann bei der Umsetzung. Die Antwort selbst musst du vorher geben.

## 20 · Mo 02.11. · 01 Strategie im Alltag · Frage · B Schwarz

Bild: rp20.jpg · Frage · B Schwarz

Du willst ein Thema voranbringen, und ein anderes Team zieht einfach nicht mit. Du hast erklärt, die Unterlagen nachgeschärft, nachgefasst. Und es bewegt sich nichts.

Der naheliegende Schluss: Das Team funktioniert nicht. Also braucht es eine Maßnahme mit dem Team.

Wenn ich in solchen Fällen genauer hinschaue, finde ich fast immer etwas anderes:

• Rollen und Zuständigkeiten sind nicht geklärt.
• Keiner weiß genau, wo das Thema hingehen soll, weil das Zielbild fehlt.
• Oder die anderen haben schlicht keinen Auftrag mitzumachen.

Der letzte Punkt tut am meisten weh. Nur weil du dir etwas wünschst und es vorantreiben willst, muss der andere Bereich nicht mitmachen. Er wird nach seinen eigenen Zielen gesteuert.

Sieh dir an, nach welchem Ziel dieses Team gesteuert wird. Und dann sei ehrlich zu dir.

Danach weißt du, ob du ein Team-Thema hast. Oder eines, das eine Ebene höher geklärt werden muss.

## 21 · Di 03.11. · 02 Komplexe Themen · Szene · B Foto mit Satz

Bild: rp21.jpg · Szene · B Foto mit Satz

„Warum nimmt die Bank unser Vertriebskonzept nicht an?“

Diese Frage kenne ich gut. Und meistens kommen die Lösungsideen gleich hinterher: noch ein Impuls, bessere Unterlagen, eine weitere Schulungsrunde. Notfalls Druck.

Dann hilft nur ein Perspektivwechsel. Setze dich gedanklich auf die andere Seite des Tisches.

Für die kooperierende Bank sieht das Ganze oft so aus:

• zu wenig Ertrag,
• zu wenige Menschen im Haus, die das Thema verstanden haben,
• und eine Anbindung an die eigenen Systeme, die so schlecht ist, dass jeder Abschluss im Alltag ein Ärgernis ist.

Dann kannst du die Vertriebsunterlagen noch so schön machen und alle noch dreimal schulen.

Ich verstehe den Wunsch, dass es dann läuft. Funktionieren wird es deswegen trotzdem nicht.

Die eigentliche Frage lautet: Was müsste passieren, damit dein Partner das Produkt gerne anbietet? Erst wenn du darauf eine Antwort hast, lohnt sich die nächste Unterlage.

## 22 · Mi 04.11. · 01 Strategie im Alltag · Werkzeug · D Zeitleiste

Bild: rp22.jpg · Werkzeug · D Zeitleiste

Wenn ich mit einem Bereichsleiter über Strategie spreche, denkt er meistens sofort an einen Zweitagesworkshop. Mit Vorbereitung, Unterlagen und Moderationskoffer.

Der Einstieg geht deutlich schneller. Und er ist entspannter, als die meisten denken.

So läuft er bei mir:

• Zwei, drei Gespräche mit dir, im Abstand von ein paar Tagen, je etwa eine Stunde. Telefon oder Video reicht. Du bereitest nichts vor. Keine Folien, keine Schlagworte. Du erzählst in deinen eigenen Worten, was dir durch den Kopf geht. Ich stelle die Fragen und unterbreche, wenn es sein muss.

• Dann strukturiere ich das, lege es neben die Logik des Geschäftsmodells Versicherung und spiegle dir, was ich gehört habe und welche Zusammenhänge darin stecken. Da entstehen die meisten Aha-Momente. Und die Grundstory steht.

• Danach besprechen wir das Vorgehen. Welche Stakeholder sind betroffen, und wie ticken sie? Wer ein Thema voranbringen will, braucht dafür eine Taktik.

Damit steht die Basis. Vertieft wird danach gezielt, wo es nötig ist.

Den ersten Schritt kannst du auch ohne mich gehen: Erzähle jemandem, dem du vertraust, eine Stunde lang ohne Unterlagen, wo dein Bereich hin soll. Und bitte ihn danach, dir zu spiegeln, was er verstanden hat.

## 23 · Do 05.11. · Geschichten aus der Praxis · Geschichte · Foto

Bild: rp23.jpg · Geschichte · Foto

Zum ersten Mal habe ich den Satz von einer Mitarbeiterin gehört. Wir saßen bei uns im Besprechungsraum und sind verschiedene Termine durchgegangen, Gespräche, Workshops.

Und sie sagte, völlig überzeugt, als wäre es das Normalste der Welt: „Naja, im Kern laufen die Termine doch immer gleich.“

Ich habe nicht verstanden, was sie meint. „Wie meinst du das?“

„Naja, es kommt immer der Punkt, an dem du sagst: Eigentlich ist es doch so. Dann stehst du auf, gehst ans Flipchart und zeichnest die Struktur. Und ab da ist sie gesetzt, weil alle verstanden haben, wo der Gesamtzusammenhang ist.“

Damals Flipchart, heute iPad. Der Moment ist derselbe geblieben.

Vorher stelle ich viele Fragen, wechsle die Perspektive und zeichne mit. So lange, bis ich den Satz sagen kann. Dann verschwindet der Nebel, und es heißt: Ja, genau so ist es. So hätte ich es nicht erklären können.

Mittlerweile sagen mir das auch Vorstände. Dass es eine Mitarbeiterin war, die es mir als Erste gespiegelt hat, ist für mich bis heute die schönere Geschichte.

## 24 · Fr 06.11. · 01 Strategie im Alltag · Zum Mitnehmen · Gedankenexperiment

Bild: rp24.jpg · Zum Mitnehmen · Gedankenexperiment

Ein Gedankenexperiment für deinen Freitag.

Stelle dir vor, deine Abteilung wird morgen ausgegründet. Eigene GmbH, eigener Auftritt. Und sie verkauft ihre Leistung an deinen bisherigen Arbeitgeber.

Was steht auf eurer Homepage?

• Wofür seid ihr da?
• Welches Problem löst ihr für wen?
• Und warum sollte das Haus euch beauftragen, statt es selbst zu machen oder woanders einzukaufen?

Jetzt kommt die eigentliche Probe: Würde jeder in deinem Team dasselbe hineinschreiben?

Wenn ja, habt ihr ein Zielbild. Jeder weiß, wie ihr erfolgreich seid und was sein Beitrag dazu ist.

Wenn nicht, weißt du, woran du in den nächsten Wochen arbeitest.

So funktioniert die Übung: Schreibe deine Fassung zuerst allein. Dann bitte drei Leute aus deinem Team, dasselbe zu tun, ohne dass sie deine Fassung kennen. Und lege die Ergebnisse nebeneinander.

## 25 · Sa 07.11. · 03 Geschäftsmodell · Weitergedacht · Foto

Bild: rp25.jpg · Weitergedacht · Foto

„Das war schon immer so.“
„Das ist bei uns gesetzt.“
„Das macht man in unserer Branche nicht.“

Drei Sätze, die ich höre, sobald es um das Geschäftsmodell von morgen geht.

Jeder für sich ist verständlich. Wer einen Bereich führt, denkt in dem Rahmen, den er kennt.

Nur ist mit jedem dieser Sätze eine Möglichkeit vom Tisch, bevor überhaupt jemand ernsthaft darüber nachgedacht hat.

Probiere am Wochenende etwas aus. Nimm eine Sache aus deinem Bereich, die als gesetzt gilt, und frage dich: Und was, wenn nicht?

Wenn es sie morgen nicht mehr gäbe: Was würde wirklich fehlen? Wer würde es merken? Und was würdest du stattdessen bauen?

## 26 · So 08.11. · 01 Strategie im Alltag · Aufgegriffen · Zitatkarte

Bild: rp26.jpg · Aufgegriffen · Zitatkarte

Peter Stockhorst, Digitalvorstand der Zurich Gruppe Deutschland, hat im Frühjahr in einem Interview beschrieben, woran es bei der Umsetzung in unserer Branche hakt.

Sein Bild: viele parallel laufende Initiativen, und die Umsetzung wird nicht überall mit derselben Konsequenz verfolgt.

Das unterschreibe ich. Und ich sehe es in den Bereichen genauso wie auf Vorstandsebene.

Mut, Führung, Tempo. Das klingt gut. Woran scheitert es im Alltag aber konkret? Aus meiner Erfahrung an drei Stellen:

• Es gibt kein klares Bild, wo es hingehen soll. Dann ist jede Initiative gleich wichtig.
• Keiner entscheidet, was wegfällt. Also läuft alles parallel weiter.
• Zwischen den Terminen passiert nichts. Das Thema wartet auf den nächsten Jour fixe.

Gegen alle drei hilft dasselbe: Einer geht in den Lead. Er sorgt dafür, dass die Bedeutung für alle klar ist, entscheidet, was wegfällt, und treibt das Thema auch zwischen den Terminen voran.

Wenn du heute zehn Initiativen in deinem Bereich hast: Welche drei würdest du stoppen, wenn du müsstest?
