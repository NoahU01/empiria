# Postings Daniel Ströbel – LinkedIn (Entwürfe, Stand 12.10.2026)

## 01 · Mi 14.10. · 02 Komplexe Themen · Modell · E Erfolgsmap

Bild: mo5.jpg · Modell · E Erfolgsmap

Dein Thema ist fachlich sauber durchdacht. Und trotzdem kommt es nicht voran.

Das erlebe ich ständig. Und die Reaktion ist fast immer dieselbe: noch eine Analyse, noch eine Berechnung, noch tiefer in die Details.

Damit wirst du nicht erfolgreicher. Fachlich warst du vorher schon gut.

Ein Thema bewegt sich, wenn die Menschen, die du dafür brauchst, es wollen. Und jeder davon hat seinen eigenen Blickwinkel, seine eigenen Ziele und seine eigenen Gründe, Ja oder Nein zu sagen.

Der Vorstand schaut auf etwas anderes als der Vertrieb. Der Nachbarbereich fragt sich, was das für ihn bedeutet. Und irgendwo sitzt jemand, an den keiner gedacht hat und an dem das Thema am Ende hängen bleibt.

Deshalb steht bei mir vor jedem Thema die Erfolgsmap:

• An wem richtest du dich mit deinem Bereich aus? Wessen Erwartungen entscheiden, ob du als erfolgreich wahrgenommen wirst?
• Wen brauchst du, um das Thema durchzubringen?
• Wen hast du bisher zu wenig beachtet?

Und dann für jeden auf der Map: Wie schaut er auf das Thema, was will er erreichen, was treibt ihn an?

Daraus ergibt sich deine Taktik. Mit wem sprichst du zuerst, wen holst du vorher ab, welches Argument zählt bei wem?

Das ist bei jedem Thema anders, weil die Menschen andere sind.

Logik und Fachlichkeit allein haben in einer Organisation noch kein Thema durchgebracht. Das machen die Menschen.

## 02 · Do 15.10. · 01 Strategie im Alltag · Szene · F Foto mit Verlauf und Wort

Bild: rp07.jpg · Szene · F Foto mit Verlauf und Wort

Dein Vorstand gibt kein Zielbild für deinen Bereich vor? Sei froh. Das ist deine Chance.

Damit hast du die Freiheit, deinen Bereich so aufzustellen, dass er erfolgreich sein kann. Genau dafür trägst du als Bereichsleiter die Verantwortung.

Wer jetzt auf Vorgaben von oben wartet, lässt diese Freiheit liegen.

Ein wohlklingender Satz auf einer Folie hilft dabei niemandem. Ein Zielbild beschreibt das Geschäftsmodell deines Bereichs, und zwar so klar, dass jeder deiner Mitarbeiter es erklären kann:

• Für wen arbeiten wir, und welchen Mehrwert liefern wir?
• Woran wird gemessen, ob wir erfolgreich sind?
• Wie müssen wir in Zukunft funktionieren? Die beste Frage dafür: Wie würdest du deinen Bereich heute neu gründen?
• Und was ist mein eigener Beitrag dazu?

Steht das, ergibt sich die Strategie fast von allein. Sie ist die Verbindung zwischen heute und diesem Bild.

Ob ein Bereich ein echtes Zielbild hat, merke ich meist in den ersten Minuten eines Termins. Die Leute leiten ihr Thema aus dem Gesamtbild ab: warum wir heute hier sind, wo es hingehen soll, mit welchem Ergebnis wir rausgehen.

Geht es um Optionen, argumentieren sie sauber und einigen sich nicht am Ende auf einen Kompromiss.

Und sie sind spürbar motivierter, weil alles, woran sie arbeiten, einen Sinn hat.

## 03 · Fr 16.10. · 02 Komplexe Themen · Szene · A Foto pur (Flipchart)

Bild: rp05.jpg · Szene · A Foto pur (Flipchart)

What's in it for me?

Diese Frage stellt sich jeder Vertriebspartner, wenn ein neues Thema auf ihn zukommt. Er stellt sie nicht laut. Aber er entscheidet danach, ob er etwas tut.

Bei Vertriebstagungen und Markteinführungen erlebe ich es immer wieder: tolle Stimmung, viele richtige Fakten, viele bunte Folien.

Wenn ich nachfrage, wie gut die Umsetzung vorbereitet ist, kommt meist kurz ein Schlucken. Und nach vier Wochen spricht keiner mehr von der Tagung.

Deshalb steht diese Frage bei uns am Anfang jeder Vorbereitung. Sie ist das Why, und zwar aus Sicht des Zuhörers: Was bedeutet das für mich? Was bringt mir das?

Erst wenn das klar ist, kommen das How, also wie er grundsätzlich vorgeht, und das What next, der konkrete nächste Schritt.

Die zweite Frage folgt direkt: Wie zeigen wir das so, dass es sofort verstanden wird, ohne große Erklärung? Show, don't tell.

Bevor du die nächste Tagung vorbereitest: Schreib für jede Zielgruppe in einem Satz auf, was sie davon hat.

Wenn dir das schwerfällt, weiß es der Vertrieb hinterher auch nicht.

## 04 · Sa 17.10. · 03 Geschäftsmodell · Weitergedacht

Bild: rp09.jpg · Weitergedacht · Gelbe Satzkarte mit Kreis

Die meisten sehen nur die Grenzen, die heute gesteckt sind.

Das ist kein Vorwurf. Wer einen Bereich führt, denkt in dem Rahmen, den er kennt: Zuständigkeiten, Systeme, Budgets.

Und kaum jemand schlägt eine Lösung vor, die seine eigene Rolle überflüssig machen würde.

Genau deshalb lohnt es sich, die Grenzen ab und zu bewusst wegzudenken.

Mit einem Schadenchef über die Frage, wie sein Schadenmanagement aussähe, wenn er es heute ohne die gewachsenen Abläufe aufbauen würde.

Mit einem Vertriebsdirektor darüber, wie er seinen Vertrieb aufstellen würde, wenn er morgen bei null anfangen dürfte.

Die Antworten sind selten sofort umsetzbar. Aber sie zeigen, welche Grenzen wirklich gesetzt sind und welche nur Gewohnheit.

Eine Voraussetzung gibt es: Der Kern muss laufen. Wer im Alltag noch Löcher stopft, hat für solche Fragen keinen Kopf.

Welche Grenze in deinem Bereich ist eigentlich nur Gewohnheit?

## 05 · So 18.10. · Geschichten aus der Praxis · Satz

Bild: rp10.jpg · Satz · B Anführungszeichen

„Das habe ich noch nicht richtig verstanden. Können Sie mir das mal in Ihren eigenen Worten erklären?“

Diesen Satz habe ich von meinem Vorstand unzählige Male gehört. Meist in Meetings, in denen wichtige Folien gezeigt und wichtige Worte benutzt wurden.

Das Bemerkenswerte: Er hatte es fast immer längst verstanden.

Er wollte wissen, ob derjenige es verstanden hat, der das Thema präsentiert und nachher umsetzen soll.

Denn das Thema muss auch dann richtig weiterlaufen, wenn der Vorstand nicht mehr im Raum ist.

Seine kleine Mikromethode. Ganz ruhig, ohne jede Schärfe. Und jedes Mal hat sie gezeigt, ob ein Thema trägt.

Ich bewundere sie bis heute.

Für beide Seiten des Tisches steckt etwas drin:

• Wer führt, hat eine Frage, die mehr prüft als jeder Statusbericht.
• Wer präsentiert, weiß, worauf es ankommt: das Thema in eigenen Worten erklären können, ohne Folie.

## 06 · Mo 19.10. · Branche eingeordnet · Eingeordnet · B Zahl auf Foto

Bild: rp08.jpg · Eingeordnet · B Zahl auf Foto

77 % sagen: Das Tagesgeschäft verdrängt die strategischen Projekte. Nur 11 % sagen, die Mitarbeitenden verstehen die Strategie.

Die Zahlen stammen aus einer branchenübergreifenden Studie von Wieselhuber. Bei Versicherern erlebe ich es nicht anders.

Was heißt das für einen Bereich? Strategie braucht im Alltag einen festen Platz, sonst gewinnt immer das, was heute brennt.

Zwei Dinge helfen.

Jeder kann in einem Satz sagen, wohin der Bereich will und warum, dann lassen sich Prioritäten im Alltag selbst entscheiden.

Und strategische Themen bekommen feste Termine im Kalender, genauso wie das Tagesgeschäft.

## 07 · Di 20.10. · 01 Strategie im Alltag · Szene · B Foto mit Satz

Bild: rp01.jpg · Szene · B Foto mit Satz

Die Strategie gibt der Chef vor. Das ist sein Job.

Ich erlebe es immer wieder: Eine neue Strategie soll her, und der erste Schritt ist ein großer Workshop mit dem ganzen Team. Alle sollen mitreden, alle sollen sich wiederfinden.

In der Praxis holst du damit Menschen an den Tisch, die nie gelernt haben, über Strategie zu sprechen, und denen die Erfahrung dafür fehlt.

Heraus kommt ein Kompromiss, auf den sich alle einigen können. Schlechtes Mittelmaß.

Nebenbei entsteht Unsicherheit. Wenn der Chef fragt, wo es hingehen soll, wirkt es, als wüsste der Trainer nicht, wohin die Mannschaft laufen soll.

Die Reihenfolge ist eine andere. Zuerst klärt die Führungskraft, wo der Bereich hinwill und wie er dort erfolgreich ist.

Dafür braucht es keinen Zweitagesworkshop, für den Einstieg reichen zwei, drei Gespräche. Danach kommt das Team dazu, wenn es um die Umsetzung geht.

Wer oben steht und selbst kein Bild hat, wohin es geht, kann das von seinen Führungskräften auch nicht verlangen.

## 08 · Mi 21.10. · 02 Komplexe Themen · Modell · A Why · How · Next

Bild: rp02.jpg · Modell · A Why · How · Next

Viele Vorstandsvorlagen sind vollständig und trotzdem nicht entscheidbar.

Wer ein Fachthema einbringt, präsentiert meist bis ins letzte Detail. Der Vorstand weiß danach viel, nur nicht, was das Thema für das Unternehmen bedeutet.

Dann geht es in die nächste Schleife.

Drei Fragen reichen, in dieser Reihenfolge:

Why. Welche Bedeutung hat dieses Thema für uns und unser Unternehmen? Kurz und auf den Punkt.

How. Wie gehen wir grundsätzlich vor? Grundsätzlich heißt: ohne die Einzelprobleme, solange die Gesamtwirkung nicht klar ist.

What next. Was ist der konkrete nächste Schritt, damit es vorangeht?

Das klingt einfach, und trotzdem lässt es sich sehr ungeschickt aufbauen.

Prüf deine nächste Vorlage gegen diese drei Fragen, bevor du an den Folien feilst.

## 09 · Do 22.10. · 01 Strategie im Alltag · Szene · B Foto mit Satz (Porträt)

Bild: rp03.jpg · Szene · B Foto mit Satz (Porträt)

„Daniel, Führung macht einsam. Je höher du kommst, desto weniger sagt dir jemand die Wahrheit.“

Diesen Satz hat mir ein ehemaliger Vorstand gesagt, mit dem ich bis heute befreundet bin. Er begleitet mich in fast jedem Projekt.

Ein Vorstand braucht mindestens einen Menschen, der auf Augenhöhe offen mit ihm spricht. Jemanden, der eine andere Meinung fundiert vertritt, ohne Angst, weil er von ihr überzeugt ist.

Und der den nächsten Schritt aufzeigt, weil sich ein Vorstand gar nicht um alle Themen selbst kümmern kann.

Wenn du selbst führst, schreib dir heute einen Namen auf: Wer sagt dir die Wahrheit?

Fällt dir niemand ein, ist das die wichtigste Aufgabe dieser Woche.

## 10 · Fr 23.10. · 01 Strategie im Alltag · Frage · E Skala

Bild: rp04.jpg · Frage · E Skala

Wie viel deiner Woche zahlt auf die Strategie ein?

Im Alltag kommt ständig etwas hoch: ein dringender Sachverhalt, eine Vorstandsbeschwerde, ein Termin, der brennt. Das muss heute geregelt werden.

Gleichzeitig steht irgendwo eine Strategie, die erreicht werden soll.

In Bereichen, in denen Strategie wirkt, ist beides sauber getrennt. Dort ist jederzeit klar, womit man sich beschäftigt und womit nicht, damit die Strategie umgesetzt wird.

Ein ehrlicher Test für diese Woche: Geh deinen Kalender durch und markiere jeden Termin, der direkt auf die Strategie einzahlt. Der Rest ist Tagesgeschäft.

Das Verhältnis zeigt dir, wo du ansetzen musst.

Und wenn dir beim Markieren nicht klar ist, was auf deine Strategie einzahlt, dann ist die Strategie nicht klar genug.

## 11 · Sa 24.10. · 03 Geschäftsmodell · Weitergedacht

Bild: rp11.jpg · Weitergedacht · Gelbe Satzkarte

„Das kommt darauf an.“

Diesen Satz habe ich letzte Woche gefühlt zehnmal gehört. Von der Anwaltshotline meiner Rechtsschutzversicherung.

Ich hatte ein konkretes Thema und wollte eine Grundeinordnung. Keine abschließende Bewertung, dafür muss man in die Verträge schauen, das ist mir klar. Genau das habe ich gleich zu Beginn gesagt.

Ich wollte eine Denkhilfe für das Gespräch mit meinem Vertragspartner. Eine Richtung.

Bekommen habe ich: Verträge prüfen. Erst mit dem Vertragspartner reden. Wenn das nicht weiterhilft, anwaltlich prüfen lassen.

Keine Einordnung. Keine Richtung. Das Gespräch hätte ich mir sparen können.

Was mich daran ärgert, ist die vergebene Chance. Versicherer können ihre Leistung meistens nur im Schadenfall zeigen. Ein Rechtsschutzversicherer hat mit so einer Hotline etwas, das sich andere wünschen: mehr Kontakte mit dem Kunden, bei denen er ein echtes Problem löst.

Beim Abschluss wird genau dieser Service groß angepriesen. Und in dem Moment, in dem ich ihn brauche, bekomme ich nicht einmal eine Richtung.

Ein Feature, das im entscheidenden Moment nicht hält, was es verspricht, schadet mehr, als wenn es gar nicht da wäre.

Wer Services verantwortet, die beim Abschluss verkauft werden: Wann hat zuletzt jemand geprüft, was davon im Ernstfall beim Kunden ankommt?
